const tenantSubdomain = "ridebridgecustomers01";
const frontendClientId = "ada68305-68f8-4d93-a869-3b9616fe41ce";
const apiClientId = "ac9d7002-2dfd-4ba3-a795-3f6ad2b99052";

export const apiScope =
    `api://${apiClientId}/access_as_user`;

export const msalConfig = {
    auth: {
        clientId: frontendClientId,
        authority:
            `https://${tenantSubdomain}.ciamlogin.com/`,
        redirectUri: `${window.location.origin}/`,
        postLogoutRedirectUri:
            `${window.location.origin}/`,
        navigateToLoginRequestUrl: true,
    },
    cache: {
        cacheLocation: "sessionStorage",
        storeAuthStateInCookie: false,
    },
};

export const loginRequest = {
    scopes: [
        "openid",
        "profile",
        apiScope,
    ],
};

export const apiConfig = {
    syncUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/sync",
    meUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/me",
    mywhooshLoginUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/mywhoosh-login",
    garminLoginStartUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/garmin-login/start",
    garminLoginCompleteUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/garmin-login/complete",
    accountDeleteUrl:
        "https://func-mywhoosh-garmin-dev-c7abdze7exa0g3a0.northeurope-01.azurewebsites.net/api/account",
};

