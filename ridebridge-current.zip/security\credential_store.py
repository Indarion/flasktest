import json
import os
import re
from functools import lru_cache

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

import base64
import tempfile
from contextlib import contextmanager
from pathlib import Path
import base64
from datetime import datetime, timedelta, timezone
from pathlib import Path

_USER_ID_PATTERN = re.compile(r"^usr-[a-z0-9-]{1,50}$")


def _validate_user_id(user_id: str) -> str:
    normalized = user_id.strip().lower()

    if not _USER_ID_PATTERN.fullmatch(normalized):
        raise ValueError("Ungültige interne Benutzer-ID.")

    return normalized


@lru_cache(maxsize=1)
def _get_secret_client() -> SecretClient:
    vault_url = os.getenv("KEY_VAULT_URL", "").strip()

    if not vault_url:
        raise RuntimeError("KEY_VAULT_URL fehlt.")

    credential = DefaultAzureCredential()

    return SecretClient(
        vault_url=vault_url,
        credential=credential,
    )


def get_garmin_session(user_id: str) -> dict:
    validated_user_id = _validate_user_id(user_id)
    secret_name = f"{validated_user_id}-garmin-session"

    secret = _get_secret_client().get_secret(secret_name)

    if not secret.value:
        raise RuntimeError("Garmin-Session ist leer.")

    package = json.loads(secret.value)

    if package.get("schema_version") != 1:
        raise RuntimeError("Unbekannte Garmin-Session-Version.")

    files = package.get("files")

    if not isinstance(files, dict) or not files:
        raise RuntimeError("Garmin-Session enthält keine Dateien.")

    return package

def get_mywhoosh_credentials(user_id: str) -> dict:
    validated_user_id = _validate_user_id(user_id)
    secret_name = f"{validated_user_id}-mywhoosh-credentials-01"

    secret = _get_secret_client().get_secret(secret_name)

    if not secret.value:
        raise RuntimeError("MyWhoosh-Credentials sind leer.")

    try:
        credentials = json.loads(secret.value)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "MyWhoosh-Credentials enthalten kein gültiges JSON."
        ) from exc

    if credentials.get("schema_version") != 1:
        raise RuntimeError(
            "Unbekannte MyWhoosh-Credential-Version."
        )

    email = credentials.get("email")
    access_token = credentials.get("access_token")

    if not isinstance(email, str) or not email.strip():
        raise RuntimeError(
            "MyWhoosh-E-Mail-Adresse fehlt."
        )

    if not isinstance(access_token, str) or not access_token.strip():
        raise RuntimeError(
            "MyWhoosh-Access-Token fehlt."
        )

    return {
        "email": email.strip(),
        "access_token": access_token.strip(),
    }

_ALLOWED_GARMIN_FILES = {
    "garmin_account.json",
    "garmin_tokens/garmin_tokens.json",
}

_REQUIRED_GARMIN_FILES = {
    "garmin_tokens/garmin_tokens.json",
}



@contextmanager
def materialize_garmin_session(user_id: str):
    package = get_garmin_session(user_id)
    files = package["files"]

    unknown_files = set(files.keys()).difference(_ALLOWED_GARMIN_FILES)
    missing_files = _REQUIRED_GARMIN_FILES.difference(
    files.keys()
)

    if unknown_files:
        raise RuntimeError("Garmin-Session enthält unerwartete Dateien.")

    if missing_files:
        raise RuntimeError("Garmin-Session ist unvollständig.")

    with tempfile.TemporaryDirectory(prefix="garmin-session-") as directory:
        root = Path(directory)

        for relative_name, encoded_content in files.items():
            target = root / relative_name
            target.parent.mkdir(parents=True, exist_ok=True)

            try:
                decoded_content = base64.b64decode(
                    encoded_content,
                    validate=True,
                )
            except ValueError as exc:
                raise RuntimeError(
                    "Garmin-Session enthält ungültige Base64-Daten."
                ) from exc

            target.write_bytes(decoded_content)

        yield root
def save_mywhoosh_credentials(
    user_id: str,
    email: str,
    access_token: str,
) -> None:
    validated_user_id = _validate_user_id(user_id)

    normalized_email = email.strip().lower()
    normalized_token = access_token.strip()

    if not normalized_email:
        raise ValueError(
            "MyWhoosh-E-Mail-Adresse fehlt."
        )

    if len(normalized_email) > 254:
        raise ValueError(
            "MyWhoosh-E-Mail-Adresse ist zu lang."
        )

    if not normalized_token:
        raise ValueError(
            "MyWhoosh-Access-Token fehlt."
        )

    secret_name = (
        f"{validated_user_id}-mywhoosh-credentials-01"
    )

    secret_value = json.dumps(
        {
            "schema_version": 1,
            "email": normalized_email,
            "access_token": normalized_token,
        },
        separators=(",", ":"),
    )

    _get_secret_client().set_secret(
        secret_name,
        secret_value,
        content_type="application/json",
        tags={
            "application": "ridebridge",
            "credential_type": "mywhoosh",
            "user_id": validated_user_id,
        },
    )
_GARMIN_SESSION_FILES = {
    "garmin_tokens.json",
}


def save_pending_garmin_mfa(
    user_id: str,
    client_state: dict,
) -> None:
    validated_user_id = _validate_user_id(user_id)

    if not isinstance(client_state, dict) or not client_state:
        raise ValueError(
            "Ungültiger Garmin-MFA-Zustand."
        )

    now = datetime.now(timezone.utc)

    secret_value = json.dumps(
        {
            "schema_version": 1,
            "created_at": now.isoformat(),
            "expires_at": (
                now + timedelta(minutes=10)
            ).isoformat(),
            "client_state": client_state,
        },
        separators=(",", ":"),
    )

    _get_secret_client().set_secret(
        f"{validated_user_id}-garmin-mfa-pending",
        secret_value,
        content_type="application/json",
        tags={
            "application": "ridebridge",
            "credential_type": "garmin-mfa-pending",
            "user_id": validated_user_id,
        },
    )


def get_pending_garmin_mfa(
    user_id: str,
) -> dict:
    validated_user_id = _validate_user_id(user_id)

    secret = _get_secret_client().get_secret(
        f"{validated_user_id}-garmin-mfa-pending"
    )

    if not secret.value:
        raise RuntimeError(
            "Garmin-MFA-Vorgang ist leer."
        )

    package = json.loads(secret.value)

    if package.get("schema_version") != 1:
        raise RuntimeError(
            "Unbekannte Garmin-MFA-Version."
        )

    expires_at_raw = package.get("expires_at")
    client_state = package.get("client_state")

    if not isinstance(expires_at_raw, str):
        raise RuntimeError(
            "Garmin-MFA-Ablaufzeit fehlt."
        )

    try:
        expires_at = datetime.fromisoformat(
            expires_at_raw
        )
    except ValueError as exc:
        raise RuntimeError(
            "Ungültige Garmin-MFA-Ablaufzeit."
        ) from exc

    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(
            tzinfo=timezone.utc
        )

    if datetime.now(timezone.utc) >= expires_at:
        raise RuntimeError(
            "Garmin-MFA-Vorgang ist abgelaufen."
        )

    if not isinstance(client_state, dict):
        raise RuntimeError(
            "Garmin-MFA-Zustand fehlt."
        )

    return client_state


def delete_pending_garmin_mfa(
    user_id: str,
) -> None:
    validated_user_id = _validate_user_id(user_id)
    now = datetime.now(timezone.utc)

    _get_secret_client().set_secret(
        f"{validated_user_id}-garmin-mfa-pending",
        json.dumps(
            {
                "schema_version": 1,
                "created_at": now.isoformat(),
                "expires_at": now.isoformat(),
                "client_state": None,
            },
            separators=(",", ":"),
        ),
        content_type="application/json",
        tags={
            "application": "ridebridge",
            "credential_type": "garmin-mfa-pending",
            "state": "cleared",
            "user_id": validated_user_id,
        },
    )


def save_garmin_session_directory(
    user_id: str,
    token_directory: Path,
) -> None:
    validated_user_id = _validate_user_id(user_id)
    token_directory = Path(token_directory)

    if not token_directory.is_dir():
        raise RuntimeError(
            "Garmin-Tokenverzeichnis fehlt."
        )

    files = {}

    for file_path in token_directory.rglob("*"):
        if not file_path.is_file():
            continue

        relative_name = (
            file_path.relative_to(token_directory)
            .as_posix()
        )

        if relative_name not in _GARMIN_SESSION_FILES:
            raise RuntimeError(
                "Unerwartete Datei in der Garmin-Session."
            )

        files[
            f"garmin_tokens/{relative_name}"
        ] = base64.b64encode(
            file_path.read_bytes()
        ).decode("ascii")

    required_file = (
        "garmin_tokens/garmin_tokens.json"
    )

    if required_file not in files:
        raise RuntimeError(
            "garmin_tokens.json wurde nicht erzeugt."
        )

    secret_value = json.dumps(
        {
            "schema_version": 1,
            "files": files,
        },
        separators=(",", ":"),
    )

    _get_secret_client().set_secret(
        f"{validated_user_id}-garmin-session",
        secret_value,
        content_type="application/json",
        tags={
            "application": "ridebridge",
            "credential_type": "garmin-session",
            "user_id": validated_user_id,
        },
    )
def delete_user_secrets(
    user_id: str,
) -> None:
    validated_user_id = _validate_user_id(user_id)

    secret_names = (
        (
            f"{validated_user_id}"
            "-mywhoosh-credentials-01"
        ),
        f"{validated_user_id}-garmin-session",
        f"{validated_user_id}-garmin-mfa-pending",
    )

    secret_client = _get_secret_client()

    for secret_name in secret_names:
        try:
            secret = secret_client.get_secret(
                secret_name
            )

        except Exception as exc:
            status_code = getattr(
                exc,
                "status_code",
                None,
            )

            if status_code == 404:
                continue

            raise

        # Sofortige weitere Verwendung verhindern.
        secret_client.update_secret_properties(
            secret.properties.version,
            secret_name,
            enabled=False,
            tags={
                **(secret.properties.tags or {}),
                "state": "account-deleted",
            },
        )

        try:
            poller = (
                secret_client.begin_delete_secret(
                    secret_name
                )
            )
            poller.wait()

        except Exception as exc:
            status_code = getattr(
                exc,
                "status_code",
                None,
            )

            if status_code != 404:
                raise