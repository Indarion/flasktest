import base64
import json

import azure.functions as func


class AuthenticationContextError(RuntimeError):
    pass


def _decode_client_principal(encoded_principal: str) -> dict:
    try:
        padding = "=" * (-len(encoded_principal) % 4)

        decoded = base64.b64decode(
            encoded_principal + padding,
            validate=True,
        )

        principal = json.loads(
            decoded.decode("utf-8")
        )

    except (
        ValueError,
        UnicodeDecodeError,
        json.JSONDecodeError,
    ) as exc:
        raise AuthenticationContextError(
            "Ungültiger X-MS-CLIENT-PRINCIPAL-Header."
        ) from exc

    if not isinstance(principal, dict):
        raise AuthenticationContextError(
            "Ungültiges Principal-Format."
        )

    return principal


def _get_claim(principal: dict, claim_names: set[str]) -> str | None:
    claims = principal.get("claims")

    if not isinstance(claims, list):
        return None

    for claim in claims:
        if not isinstance(claim, dict):
            continue

        claim_type = str(
            claim.get("typ", "")
        ).strip()

        claim_value = str(
            claim.get("val", "")
        ).strip()

        if claim_type in claim_names and claim_value:
            return claim_value

    return None


def get_authenticated_user(
    req: func.HttpRequest,
) -> dict:
    principal_id = (
        req.headers.get("X-MS-CLIENT-PRINCIPAL-ID", "")
        .strip()
        .lower()
    )

    encoded_principal = req.headers.get(
        "X-MS-CLIENT-PRINCIPAL",
        "",
    ).strip()

    if not principal_id or not encoded_principal:
        raise AuthenticationContextError(
            "Authentifizierte Benutzeridentität fehlt."
        )

    principal = _decode_client_principal(
        encoded_principal
    )

    tenant_id = _get_claim(
        principal,
        {
            "tid",
            "http://schemas.microsoft.com/identity/claims/tenantid",
        },
    )

    subject = _get_claim(
        principal,
        {
            "sub",
            "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
        },
    )

    display_name = _get_claim(
        principal,
        {
            "name",
            "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name",
        },
    )

    if not tenant_id:
        raise AuthenticationContextError(
            "Tenant-Claim fehlt."
        )

    return {
        "principal_id": principal_id,
        "tenant_id": tenant_id.lower(),
        "subject": subject,
        "display_name": display_name,
    }