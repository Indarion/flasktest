#!/usr/bin/env python3
"""MyWhoosh -> neueste Aktivitaet als FIT -> Garmin.

Login mit Passwort. Fuer die lokale Skriptnutzung kann bei einem allgemeinen
Loginfehler auf einen zuvor gespeicherten Bearer-Token zurueckgegriffen werden.
Die Azure Function verwendet password_login() direkt und speichert Tokens im
Azure Key Vault.
"""

import argparse
import base64
import getpass
import hashlib
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

LOGIN = "https://services.mywhoosh.com/http-service/api/login"
ACTIVITIES = "https://service14.mywhoosh.com/v2/rider/profile/activities"
DOWNLOAD = "https://service14.mywhoosh.com/v2/rider/profile/download-activity-file"
PAYLOAD_KEY = "D9436E508087E863"

try:
    BASE_DIR = Path(__file__).resolve().parent
except NameError:
    BASE_DIR = Path.cwd()

TOKEN_FILE = BASE_DIR / "mywhoosh_tokens.json"


class MyWhooshHttpError(RuntimeError):
    def __init__(self, label: str, status_code: int):
        self.label = label
        self.status_code = status_code
        super().__init__(f"{label}: HTTP {status_code}.")


class MyWhooshAlreadyLoggedInError(RuntimeError):
    """MyWhoosh rejected login because another device session is active."""


# ---------------------------------------------------------------- Token-Speicher

def _read_tokens():
    try:
        data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def load_token(email):
    entry = _read_tokens().get(email.strip().lower())
    return entry.get("token") if isinstance(entry, dict) else None


def save_token(email, token):
    tokens = _read_tokens()
    tokens[email.strip().lower()] = {
        "token": token,
        "saved_at": datetime.now(timezone.utc).isoformat(),
    }
    TOKEN_FILE.write_text(json.dumps(tokens, indent=2), encoding="utf-8")


# ---------------------------------------------------------------- API-Helfer

def encrypt(payload):
    salt = os.urandom(8)
    derived, block = b"", b""
    while len(derived) < 48:
        block = hashlib.md5(
            block + PAYLOAD_KEY.encode("utf-8") + salt
        ).digest()
        derived += block

    raw = json.dumps(
        payload,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")

    cipher = AES.new(derived[:32], AES.MODE_CBC, derived[32:48])
    encrypted = cipher.encrypt(pad(raw, 16))
    return base64.b64encode(b"Salted__" + salt + encrypted).decode("ascii")


def response_json(response, label):
    if not response.ok:
        raise MyWhooshHttpError(
            label=label,
            status_code=response.status_code,
        )

    try:
        value = response.json()
    except ValueError:
        raise RuntimeError(f"{label}: Antwort ist kein JSON.") from None

    if not isinstance(value, dict):
        raise RuntimeError(f"{label}: Unerwartetes JSON-Format.")

    return value


def post_api(session, url, payload, label):
    response = session.post(
        url,
        json=encrypt(payload),
        timeout=(15, 60),
        allow_redirects=False,
    )
    body = response_json(response, label)
    if body.get("error") is not False or body.get("code") != 200:
        raise RuntimeError(
            f"{label}: API meldet keinen Erfolg (code={body.get('code')})."
        )
    return body.get("data")


def activity_timestamp(activity):
    value = activity.get("startDatetime")
    if value:
        try:
            return datetime.fromisoformat(
                value.replace("Z", "+00:00")
            ).timestamp()
        except (ValueError, TypeError):
            pass

    try:
        return float(activity["date"])
    except (KeyError, ValueError, TypeError):
        raise RuntimeError(
            "Aktivitaet ohne auswertbares Startdatum; Auswahl abgebrochen."
        ) from None


def get_latest(session):
    activities = []
    seen_ids = set()
    page = 1

    while True:
        data = post_api(
            session,
            ACTIVITIES,
            {"type": "", "page": page, "sortDate": "DESC"},
            "Aktivitaeten",
        )

        if not isinstance(data, dict) or not isinstance(
            data.get("results"), list
        ):
            raise RuntimeError(
                "Aktivitaeten: data.results fehlt oder ist keine Liste."
            )

        current = int(data.get("currentPage", page))
        total = int(data.get("totalPages", 1))
        if current != page:
            raise RuntimeError(
                "Aktivitaeten: Server liefert eine unerwartete Seitennummer."
            )

        rows = data["results"]
        if page > 1 and not rows:
            raise RuntimeError(
                "Aktivitaeten: Unerwartete leere Folgeseite."
            )

        for row in rows:
            if not isinstance(row, dict):
                raise RuntimeError(
                    "Aktivitaeten: Unerwarteter Listeneintrag."
                )
            identifier = row.get("id") or row.get("activityFileId")
            if identifier not in seen_ids:
                seen_ids.add(identifier)
                activities.append(row)

        if page >= total:
            break
        if page >= 1000:
            raise RuntimeError(
                "Aktivitaeten: Sicherheitslimit fuer Pagination erreicht."
            )
        page += 1

    if not activities:
        return None, 0

    latest = max(activities, key=activity_timestamp)
    if not latest.get("activityFileId"):
        raise RuntimeError(
            "Neueste Aktivitaet hat keine activityFileId; "
            "kein Rueckgriff auf aeltere Fahrt."
        )

    return latest, len(activities)


def download_fit(url, target):
    parsed = urlsplit(url)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
    ):
        raise RuntimeError(
            "Download-Link ist keine gueltige HTTPS-Adresse."
        )

    temporary = target.with_suffix(".fit.part")
    try:
        with requests.get(
            url,
            stream=True,
            timeout=(15, 120),
            allow_redirects=False,
        ) as response:
            if response.status_code != 200:
                raise RuntimeError(
                    f"FIT-Download: HTTP {response.status_code}. "
                    "Erneuter Skriptstart fordert einen frischen Link an."
                )

            total = 0
            with temporary.open("wb") as output:
                for chunk in response.iter_content(65536):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > 256 * 1024 * 1024:
                        raise RuntimeError(
                            "FIT-Download ueberschreitet das "
                            "Sicherheitslimit von 256 MiB."
                        )
                    output.write(chunk)

        with temporary.open("rb") as handle:
            header = handle.read(14)

        if len(header) < 12 or header[8:12] != b".FIT":
            raise RuntimeError(
                "Download hat keine FIT-Signatur; Datei wird nicht uebernommen."
            )

        expected = header[0] + int.from_bytes(header[4:8], "little") + 2
        if header[0] not in (12, 14) or total != expected:
            raise RuntimeError(
                "FIT-Header oder Dateilaenge ist unplausibel; "
                "Datei wird nicht uebernommen."
            )

        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)


# ---------------------------------------------------------------- Login

def ask_password():
    password = os.getenv("MYWHOOSH_PASSWORD")
    if password:
        return password
    try:
        return getpass.getpass("MyWhoosh-Passwort: ")
    except Exception:
        return input("MyWhoosh-Passwort: ")


def password_login(session, email, password):
    """Return a bearer token or raise a specific login exception."""
    response = session.post(
        LOGIN,
        json={
            "Username": email,
            "Password": password,
            "Platform": "Android",
            "Action": 1001,
            "CorrelationId": str(uuid.uuid4()),
            "DeviceId": "device-id",
            "Authorization": "",
        },
        timeout=(15, 60),
        allow_redirects=False,
    )
    login = response_json(response, "Login")

    if login.get("Success") is True and login.get("AccessToken"):
        return login["AccessToken"]

    response_message = str(
        login.get("Message", login.get("message", "")) or ""
    ).strip()

    if "already logged in from another device" in response_message.lower():
        raise MyWhooshAlreadyLoggedInError(
            "MyWhoosh reports an active login on another device."
        )

    diagnostic = {
        "Success": login.get("Success"),
        "Message": response_message or None,
        "UserStatus": login.get("UserStatus"),
        "Action": login.get("Action"),
        "AccessToken_vorhanden": bool(login.get("AccessToken")),
    }
    raise RuntimeError(
        "MyWhoosh-Loginantwort: "
        + json.dumps(diagnostic, ensure_ascii=False)
    )


def authenticate(session, email, password):
    """Password login with a local-script fallback to a cached bearer token."""
    try:
        token = password_login(session, email, password)
    except MyWhooshAlreadyLoggedInError:
        # Do not hide this actionable state with a cached-token fallback.
        raise
    except RuntimeError as exc:
        print(f"Passwort-Login fehlgeschlagen: {exc}")
        cached = load_token(email)
        if not cached:
            raise RuntimeError(
                "Kein gespeicherter Bearer-Token fuer diese E-Mail vorhanden."
            ) from None

        print("Versuche gespeicherten Bearer-Token ...")
        session.headers["Authorization"] = "Bearer " + cached
        try:
            result = get_latest(session)
        except RuntimeError as exc2:
            print("Bearer-Token: FUNKTIONIERT NICHT.")
            raise RuntimeError(
                f"Gespeicherter Token ungueltig ({exc2})."
            ) from None

        print(
            "Bearer-Token: FUNKTIONIERT. "
            "Anmeldung mit gespeichertem Token erfolgreich."
        )
        return result

    save_token(email, token)
    session.headers["Authorization"] = "Bearer " + token
    print("Passwort-Login erfolgreich, Token gespeichert.")
    return get_latest(session)


# ---------------------------------------------------------------- main
# The original interactive main block remains intentionally disabled because
# RideBridge uses these helper functions from the Azure Function.
