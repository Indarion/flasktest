import os
from datetime import datetime, timedelta, timezone
from functools import lru_cache

from azure.core import MatchConditions
from azure.core.exceptions import (
    HttpResponseError,
    ResourceNotFoundError,
)
from azure.data.tables import TableClient, UpdateMode
from azure.identity import DefaultAzureCredential


_MAX_FAILURES = 5
_WINDOW = timedelta(minutes=15)
_MIN_INTERVAL = timedelta(seconds=5)
_MAX_UPDATE_RETRIES = 3

_GARMIN_MAX_FAILURES = 3
_GARMIN_WINDOW = timedelta(minutes=30)
_GARMIN_MIN_INTERVAL = timedelta(seconds=10)

class LoginRateLimitExceeded(RuntimeError):
    def __init__(self, retry_after_seconds: int):
        self.retry_after_seconds = max(
            1,
            retry_after_seconds,
        )

        super().__init__(
            "Zu viele MyWhoosh-Anmeldeversuche."
        )


@lru_cache(maxsize=1)
def _get_login_attempts_client() -> TableClient:
    endpoint = os.getenv(
        "TABLE_STORAGE_ENDPOINT",
        "",
    ).strip()

    table_name = os.getenv(
        "LOGIN_ATTEMPTS_TABLE",
        "",
    ).strip()

    if not endpoint:
        raise RuntimeError(
            "TABLE_STORAGE_ENDPOINT fehlt."
        )

    if not table_name:
        raise RuntimeError(
            "LOGIN_ATTEMPTS_TABLE fehlt."
        )

    return TableClient(
        endpoint=endpoint,
        table_name=table_name,
        credential=DefaultAzureCredential(),
    )


def _seconds_until(target: datetime, now: datetime) -> int:
    return max(
        1,
        int((target - now).total_seconds()) + 1,
    )


def check_mywhoosh_login_allowed(user_id: str) -> None:
    now = datetime.now(timezone.utc)
    client = _get_login_attempts_client()

    try:
        entity = client.get_entity(
            partition_key=user_id,
            row_key="mywhoosh",
        )
    except ResourceNotFoundError:
        return

    window_started = entity.get("WindowStartedAt")
    last_attempt = entity.get("LastAttemptAt")
    failed_attempts = int(
        entity.get("FailedAttempts", 0)
    )

    if (
        isinstance(window_started, datetime)
        and window_started.tzinfo is None
    ):
        window_started = window_started.replace(
            tzinfo=timezone.utc
        )

    if (
        isinstance(last_attempt, datetime)
        and last_attempt.tzinfo is None
    ):
        last_attempt = last_attempt.replace(
            tzinfo=timezone.utc
        )

    if (
        isinstance(last_attempt, datetime)
        and now - last_attempt < _MIN_INTERVAL
    ):
        raise LoginRateLimitExceeded(
            _seconds_until(
                last_attempt + _MIN_INTERVAL,
                now,
            )
        )

    if (
        not isinstance(window_started, datetime)
        or now - window_started >= _WINDOW
    ):
        return

    if failed_attempts >= _MAX_FAILURES:
        raise LoginRateLimitExceeded(
            _seconds_until(
                window_started + _WINDOW,
                now,
            )
        )


def record_mywhoosh_login_failure(
    user_id: str,
) -> None:
    client = _get_login_attempts_client()

    for _ in range(_MAX_UPDATE_RETRIES):
        now = datetime.now(timezone.utc)

        try:
            entity = client.get_entity(
                partition_key=user_id,
                row_key="mywhoosh",
            )
        except ResourceNotFoundError:
            try:
                client.create_entity(
                    {
                        "PartitionKey": user_id,
                        "RowKey": "mywhoosh",
                        "FailedAttempts": 1,
                        "WindowStartedAt": now,
                        "LastAttemptAt": now,
                        "SchemaVersion": 1,
                    }
                )
                return
            except HttpResponseError as exc:
                if exc.status_code == 409:
                    continue
                raise

        window_started = entity.get(
            "WindowStartedAt"
        )

        if (
            isinstance(window_started, datetime)
            and window_started.tzinfo is None
        ):
            window_started = window_started.replace(
                tzinfo=timezone.utc
            )

        if (
            not isinstance(window_started, datetime)
            or now - window_started >= _WINDOW
        ):
            failed_attempts = 1
            window_started = now
        else:
            failed_attempts = int(
                entity.get("FailedAttempts", 0)
            ) + 1

        updated_entity = {
            "PartitionKey": user_id,
            "RowKey": "mywhoosh",
            "FailedAttempts": failed_attempts,
            "WindowStartedAt": window_started,
            "LastAttemptAt": now,
            "SchemaVersion": 1,
        }

        try:
            client.update_entity(
                entity=updated_entity,
                mode=UpdateMode.REPLACE,
                etag=entity.metadata["etag"],
                match_condition=(
                    MatchConditions.IfNotModified
                ),
            )
            return
        except HttpResponseError as exc:
            if exc.status_code in {409, 412}:
                continue
            raise

    raise RuntimeError(
        "Login-Versuch konnte nicht atomar gespeichert werden."
    )


def clear_mywhoosh_login_failures(
    user_id: str,
) -> None:
    client = _get_login_attempts_client()

    try:
        client.delete_entity(
            partition_key=user_id,
            row_key="mywhoosh",
        )
    except ResourceNotFoundError:
        pass
def check_garmin_login_allowed(
    user_id: str,
) -> None:
    now = datetime.now(timezone.utc)
    client = _get_login_attempts_client()

    try:
        entity = client.get_entity(
            partition_key=user_id,
            row_key="garmin",
        )
    except ResourceNotFoundError:
        return

    window_started = entity.get("WindowStartedAt")
    last_attempt = entity.get("LastAttemptAt")
    failed_attempts = int(
        entity.get("FailedAttempts", 0)
    )

    if (
        isinstance(window_started, datetime)
        and window_started.tzinfo is None
    ):
        window_started = window_started.replace(
            tzinfo=timezone.utc
        )

    if (
        isinstance(last_attempt, datetime)
        and last_attempt.tzinfo is None
    ):
        last_attempt = last_attempt.replace(
            tzinfo=timezone.utc
        )

    if (
        isinstance(last_attempt, datetime)
        and now - last_attempt < _GARMIN_MIN_INTERVAL
    ):
        raise LoginRateLimitExceeded(
            _seconds_until(
                last_attempt + _GARMIN_MIN_INTERVAL,
                now,
            )
        )

    if (
        not isinstance(window_started, datetime)
        or now - window_started >= _GARMIN_WINDOW
    ):
        return

    if failed_attempts >= _GARMIN_MAX_FAILURES:
        raise LoginRateLimitExceeded(
            _seconds_until(
                window_started + _GARMIN_WINDOW,
                now,
            )
        )


def record_garmin_login_failure(
    user_id: str,
) -> None:
    client = _get_login_attempts_client()

    for _ in range(_MAX_UPDATE_RETRIES):
        now = datetime.now(timezone.utc)

        try:
            entity = client.get_entity(
                partition_key=user_id,
                row_key="garmin",
            )

        except ResourceNotFoundError:
            try:
                client.create_entity(
                    {
                        "PartitionKey": user_id,
                        "RowKey": "garmin",
                        "FailedAttempts": 1,
                        "WindowStartedAt": now,
                        "LastAttemptAt": now,
                        "SchemaVersion": 1,
                    }
                )
                return

            except HttpResponseError as exc:
                if exc.status_code == 409:
                    continue

                raise

        window_started = entity.get(
            "WindowStartedAt"
        )

        if (
            isinstance(window_started, datetime)
            and window_started.tzinfo is None
        ):
            window_started = window_started.replace(
                tzinfo=timezone.utc
            )

        if (
            not isinstance(window_started, datetime)
            or now - window_started >= _GARMIN_WINDOW
        ):
            failed_attempts = 1
            window_started = now
        else:
            failed_attempts = int(
                entity.get("FailedAttempts", 0)
            ) + 1

        updated_entity = {
            "PartitionKey": user_id,
            "RowKey": "garmin",
            "FailedAttempts": failed_attempts,
            "WindowStartedAt": window_started,
            "LastAttemptAt": now,
            "SchemaVersion": 1,
        }

        try:
            client.update_entity(
                entity=updated_entity,
                mode=UpdateMode.REPLACE,
                etag=entity.metadata["etag"],
                match_condition=(
                    MatchConditions.IfNotModified
                ),
            )
            return

        except HttpResponseError as exc:
            if exc.status_code in {409, 412}:
                continue

            raise

    raise RuntimeError(
        "Garmin-Loginversuch konnte nicht "
        "atomar gespeichert werden."
    )


def clear_garmin_login_failures(
    user_id: str,
) -> None:
    client = _get_login_attempts_client()

    try:
        client.delete_entity(
            partition_key=user_id,
            row_key="garmin",
        )
    except ResourceNotFoundError:
        pass
def delete_all_login_attempts_for_user(
    user_id: str,
) -> int:
    client = _get_login_attempts_client()

    entities = client.query_entities(
        query_filter="PartitionKey eq @user_id",
        parameters={
            "user_id": user_id,
        },
        select=[
            "PartitionKey",
            "RowKey",
        ],
    )

    deleted_count = 0

    for entity in entities:
        client.delete_entity(
            partition_key=entity["PartitionKey"],
            row_key=entity["RowKey"],
        )

        deleted_count += 1

    return deleted_count