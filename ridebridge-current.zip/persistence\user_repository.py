import hashlib
import os
from azure.data.tables import TableClient, UpdateMode
from datetime import datetime, timezone
from functools import lru_cache


from azure.core.exceptions import ResourceExistsError
from azure.data.tables import TableClient
from azure.identity import DefaultAzureCredential

from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError,
)
from azure.data.tables import TableClient, UpdateMode

@lru_cache(maxsize=1)
def _get_users_table_client() -> TableClient:
    endpoint = os.getenv(
        "TABLE_STORAGE_ENDPOINT",
        "",
    ).strip()

    table_name = os.getenv(
        "APP_USERS_TABLE",
        "",
    ).strip()

    if not endpoint:
        raise RuntimeError(
            "TABLE_STORAGE_ENDPOINT fehlt."
        )

    if not table_name:
        raise RuntimeError(
            "APP_USERS_TABLE fehlt."
        )

    return TableClient(
        endpoint=endpoint,
        table_name=table_name,
        credential=DefaultAzureCredential(),
    )


def _build_internal_user_id(
    tenant_id: str,
    principal_id: str,
) -> str:
    source = (
        f"{tenant_id.strip().lower()}:"
        f"{principal_id.strip().lower()}"
    )

    digest = hashlib.sha256(
        source.encode("utf-8")
    ).hexdigest()

    return f"usr-{digest[:24]}"


def get_or_create_user(
    tenant_id: str,
    principal_id: str,
    display_name: str | None = None,
) -> dict:
    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = principal_id.strip().lower()

    if not normalized_tenant_id:
        raise ValueError("Tenant-ID fehlt.")

    if not normalized_principal_id:
        raise ValueError("Principal-ID fehlt.")

    internal_user_id = _build_internal_user_id(
        normalized_tenant_id,
        normalized_principal_id,
    )

    partition_key = normalized_tenant_id
    row_key = normalized_principal_id

    table_client = _get_users_table_client()

    try:
        entity = table_client.get_entity(
            partition_key=partition_key,
            row_key=row_key,
        )

        return dict(entity)

    except Exception as exc:
        from azure.core.exceptions import ResourceNotFoundError

        if not isinstance(exc, ResourceNotFoundError):
            raise

    now = datetime.now(timezone.utc)

    entity = {
        "PartitionKey": partition_key,
        "RowKey": row_key,
        "InternalUserId": internal_user_id,
        "Status": "active",
        "Plan": "free",
        "CreatedAt": now,
        "LastLoginAt": now,
        "MyWhooshConnected": False,
        "GarminConnected": False,
        "SchemaVersion": 1,
    }

    if display_name:
        entity["DisplayName"] = display_name[:128]

    try:
        table_client.create_entity(entity)

    except ResourceExistsError:
        # Ein paralleler erster Request hat den Benutzer angelegt.
        pass

    stored_entity = table_client.get_entity(
        partition_key=partition_key,
        row_key=row_key,
    )

    return dict(stored_entity)

def set_connection_status(
    tenant_id: str,
    principal_id: str,
    *,
    mywhoosh_connected: bool | None = None,
    garmin_connected: bool | None = None,
) -> None:
    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = principal_id.strip().lower()

    if not normalized_tenant_id:
        raise ValueError("Tenant-ID fehlt.")

    if not normalized_principal_id:
        raise ValueError("Principal-ID fehlt.")

    entity = {
        "PartitionKey": normalized_tenant_id,
        "RowKey": normalized_principal_id,
        "LastUpdatedAt": datetime.now(timezone.utc),
    }

    if mywhoosh_connected is not None:
        entity["MyWhooshConnected"] = bool(
            mywhoosh_connected
        )

    if garmin_connected is not None:
        entity["GarminConnected"] = bool(
            garmin_connected
        )

    _get_users_table_client().upsert_entity(
        entity=entity,
        mode=UpdateMode.MERGE,
    )
def delete_app_user(
    tenant_id: str,
    principal_id: str,
) -> None:
    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = (
        principal_id.strip().lower()
    )

    try:
        _get_users_table_client().delete_entity(
            partition_key=normalized_tenant_id,
            row_key=normalized_principal_id,
        )

    except ResourceNotFoundError:
        pass
def mark_user_deleting(
    tenant_id: str,
    principal_id: str,
) -> None:
    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = principal_id.strip().lower()

    if not normalized_tenant_id:
        raise ValueError("Tenant-ID fehlt.")

    if not normalized_principal_id:
        raise ValueError("Principal-ID fehlt.")

    _get_users_table_client().update_entity(
        entity={
            "PartitionKey": normalized_tenant_id,
            "RowKey": normalized_principal_id,
            "Status": "deleting",
            "MyWhooshConnected": False,
            "GarminConnected": False,
            "LastUpdatedAt": datetime.now(timezone.utc),
        },
        mode=UpdateMode.MERGE,
    )


def delete_app_user(
    tenant_id: str,
    principal_id: str,
) -> None:
    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = principal_id.strip().lower()

    if not normalized_tenant_id:
        raise ValueError("Tenant-ID fehlt.")

    if not normalized_principal_id:
        raise ValueError("Principal-ID fehlt.")

    try:
        _get_users_table_client().delete_entity(
            partition_key=normalized_tenant_id,
            row_key=normalized_principal_id,
        )
    except ResourceNotFoundError:
        pass