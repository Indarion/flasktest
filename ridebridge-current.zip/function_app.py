import hashlib
import json
import logging
import os
import tempfile
import uuid
from pathlib import Path

import azure.functions as func
import requests
from garminconnect import (
    Garmin,
    GarminConnectAuthenticationError,
    GarminConnectConnectionError,
    GarminConnectTooManyRequestsError,
)

import mywhoosh_client as mw
from garmin_upload import import_result
from fit_compatibility import (
    FitCompatibilityError,
    make_garmin_compatible_fit,
)
from persistence.login_rate_limit import (
    LoginRateLimitExceeded,
    check_garmin_login_allowed,
    check_mywhoosh_login_allowed,
    clear_garmin_login_failures,
    clear_mywhoosh_login_failures,
    record_garmin_login_failure,
    record_mywhoosh_login_failure,
    delete_all_login_attempts_for_user,
)
from persistence.upload_history import (
    acquire_upload_lock,
    release_upload_lock,
    save_upload,
    delete_all_uploads_for_user,
)
from persistence.user_repository import (
    get_or_create_user,
    set_connection_status,
    delete_app_user,
    mark_user_deleting,
)
from security.authenticated_user import get_authenticated_user
from security.credential_store import (
    delete_pending_garmin_mfa,
    get_mywhoosh_credentials,
    get_pending_garmin_mfa,
    materialize_garmin_session,
    save_garmin_session_directory,
    save_mywhoosh_credentials,
    save_pending_garmin_mfa,
    delete_user_secrets,
)

from persistence.account_deletion import (
    create_account_deletion_request,
    mark_deletion_failed,
    mark_ridebridge_data_deleted,
    update_deletion_stage,
)


app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


if os.getenv("ENABLE_DIAGNOSTIC_ENDPOINTS", "false").strip().lower() == "true":
    from diagnostics import diagnostics_bp

    app.register_functions(diagnostics_bp)
    logging.warning("Diagnoseendpunkte sind aktiviert.")


class GarminReconnectRequiredError(RuntimeError):
    pass


def _is_garmin_duplicate_activity_error(exc: Exception) -> bool:
    error_text = str(exc).lower()
    return "api error 409" in error_text and "duplicate activity" in error_text


def _is_setting_enabled(name: str, default: bool = False) -> bool:
    raw_value = os.getenv(name, str(default)).strip().lower()
    if raw_value in {"1", "true", "yes", "on"}:
        return True
    if raw_value in {"0", "false", "no", "off"}:
        return False
    raise RuntimeError(f"Environment setting {name} must be true or false.")


def _garmin_login_required_response(error_id: str) -> func.HttpResponse:
    return _json_response(
        {
            "code": "GARMIN_LOGIN_REQUIRED",
            "message": "Garmin must be reconnected.",
            "error_id": error_id,
        },
        401,
    )


def _json_response(body: dict, status_code: int) -> func.HttpResponse:
    return func.HttpResponse(
        body=json.dumps(body, separators=(",", ":")),
        status_code=status_code,
        mimetype="application/json",
    )


def _mywhoosh_login_required_response() -> func.HttpResponse:
    return _json_response(
        {
            "code": "MYWHOOSH_LOGIN_REQUIRED",
            "message": "MyWhoosh muss erneut verbunden werden.",
        },
        401,
    )


def _resolve_active_app_user(req: func.HttpRequest) -> tuple[dict, dict]:
    authenticated_user = get_authenticated_user(req)
    app_user = get_or_create_user(
        tenant_id=authenticated_user["tenant_id"],
        principal_id=authenticated_user["principal_id"],
        display_name=authenticated_user["display_name"],
    )

    if app_user.get("Status") != "active":
        raise PermissionError("RideBridge user is disabled.")

    return authenticated_user, app_user


@app.route(route="health", methods=["GET"])
def health(req: func.HttpRequest) -> func.HttpResponse:
    return _json_response({"status": "ok"}, 200)


@app.route(route="me", methods=["GET"])
def me(req: func.HttpRequest) -> func.HttpResponse:
    try:
        _, app_user = _resolve_active_app_user(req)
        return _json_response(
            {
                "user_id": app_user["InternalUserId"],
                "status": app_user["Status"],
                "plan": app_user["Plan"],
                "mywhoosh_connected": app_user["MyWhooshConnected"],
                "garmin_connected": app_user["GarminConnected"],
            },
            200,
        )
    except PermissionError:
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account is disabled.",
            },
            403,
        )
    except Exception as exc:
        logging.exception(
            "User provisioning failed. exception_type=%s",
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "USER_PROVISIONING_FAILED",
                "message": "The user account could not be initialized.",
            },
            500,
        )


@app.route(route="account", methods=["DELETE"])
def delete_account(req: func.HttpRequest) -> func.HttpResponse:
    deletion_id = str(uuid.uuid4())
    stage = "request_received"
    user_id = None
    deletion_report_created = False

    try:
        authenticated_user, app_user = _resolve_active_app_user(req)
        user_id = app_user["InternalUserId"]

        try:
            request_body = req.get_json()
        except ValueError:
            request_body = None

        confirmation = (
            str(request_body.get("confirmation", "")).strip()
            if isinstance(request_body, dict)
            else ""
        )
        if confirmation != "DELETE":
            return _json_response(
                {
                    "code": "ACCOUNT_DELETE_CONFIRMATION_REQUIRED",
                    "message": "Type DELETE to confirm account deletion.",
                },
                400,
            )

        tenant_id = authenticated_user["tenant_id"]
        principal_id = authenticated_user["principal_id"]

        stage = "create_deletion_request"
        create_account_deletion_request(
            deletion_id=deletion_id,
            tenant_id=tenant_id,
            principal_id=principal_id,
            internal_user_id=user_id,
        )
        deletion_report_created = True

        stage = "mark_user_deleting"
        update_deletion_stage(deletion_id=deletion_id, stage=stage)
        mark_user_deleting(tenant_id=tenant_id, principal_id=principal_id)

        stage = "delete_user_secrets"
        update_deletion_stage(deletion_id=deletion_id, stage=stage)
        secret_results = delete_user_secrets(user_id)

        stage = "delete_upload_history"
        update_deletion_stage(deletion_id=deletion_id, stage=stage)
        deleted_uploads = delete_all_uploads_for_user(user_id)

        stage = "delete_login_attempts"
        update_deletion_stage(deletion_id=deletion_id, stage=stage)
        deleted_login_attempts = delete_all_login_attempts_for_user(user_id)

        stage = "delete_app_user"
        update_deletion_stage(deletion_id=deletion_id, stage=stage)
        delete_app_user(tenant_id=tenant_id, principal_id=principal_id)

        stage = "mark_ridebridge_data_deleted"
        mark_ridebridge_data_deleted(
            deletion_id=deletion_id,
            deleted_uploads_count=deleted_uploads,
            deleted_login_attempts_count=deleted_login_attempts,
            mywhoosh_secret_deleted=secret_results["mywhoosh_secret_deleted"],
            garmin_session_deleted=secret_results["garmin_session_deleted"],
            garmin_mfa_state_deleted=secret_results["garmin_mfa_state_deleted"],
        )

        logging.warning(
            "RideBridge account data deleted. deletion_id=%s user_id=%s "
            "deleted_uploads=%s deleted_login_attempts=%s",
            deletion_id, user_id, deleted_uploads, deleted_login_attempts,
        )
        return _json_response(
            {
                "status": "pending_identity_deletion",
                "message": (
                    "RideBridge account data was deleted. "
                    "Identity deletion is pending."
                ),
                "deletion_id": deletion_id,
            },
            202,
        )

    except PermissionError:
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account cannot be used.",
            },
            403,
        )
    except Exception as exc:
        logging.exception(
            "Account deletion failed. deletion_id=%s user_id=%s "
            "stage=%s exception_type=%s",
            deletion_id, user_id, stage, type(exc).__name__,
        )
        if deletion_report_created:
            try:
                mark_deletion_failed(
                    deletion_id=deletion_id,
                    failed_stage=stage,
                    error_id=deletion_id,
                )
            except Exception:
                logging.exception(
                    "Deletion report could not be updated. deletion_id=%s",
                    deletion_id,
                )
        return _json_response(
            {
                "code": "ACCOUNT_DELETION_FAILED",
                "message": "The account could not be deleted completely.",
                "error_id": deletion_id,
            },
            500,
        )


@app.route(route="sync", methods=["POST"])
def sync(req: func.HttpRequest) -> func.HttpResponse:
    user_id = None
    locked_file_hash = None
    sync_id = str(uuid.uuid4())
    stage = "request_received"

    logging.info("Sync started. sync_id=%s user_id=%s stage=%s", sync_id, user_id, stage)

    try:
        request_body = req.get_json()
    except ValueError:
        request_body = {}

    if request_body.get("confirmUpload") is not True:
        return func.HttpResponse(
            'Synchronisierung nicht ausgeführt. JSON-Body {"confirmUpload": true} erforderlich.',
            status_code=400,
        )

    try:
        stage = "resolve_authenticated_user"
        authenticated_user, app_user = _resolve_active_app_user(req)
        user_id = app_user["InternalUserId"]
        logging.info("Authenticated user resolved. sync_id=%s user_id=%s", sync_id, user_id)

        stage = "load_mywhoosh_credentials"
        mywhoosh_credentials = get_mywhoosh_credentials(user_id)

        with requests.Session() as mywhoosh_session:
            mywhoosh_session.headers.update(
                {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + mywhoosh_credentials["access_token"],
                }
            )

            try:
                stage = "get_latest_activity"
                latest_activity, activity_count = mw.get_latest(mywhoosh_session)
            except mw.MyWhooshHttpError as exc:
                if exc.status_code in {401, 403}:
                    set_connection_status(
                        tenant_id=authenticated_user["tenant_id"],
                        principal_id=authenticated_user["principal_id"],
                        mywhoosh_connected=False,
                    )
                    return _mywhoosh_login_required_response()
                raise

            if latest_activity is None:
                return func.HttpResponse("Keine MyWhoosh-Aktivität vorhanden.", status_code=404)

            file_id = str(latest_activity.get("activityFileId", "")).strip()
            allowed_characters = (
                "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
            )
            if not file_id or any(character not in allowed_characters for character in file_id):
                raise RuntimeError("MyWhoosh lieferte eine ungültige activityFileId.")

            try:
                stage = "get_download_url"
                download_url = mw.post_api(
                    mywhoosh_session, mw.DOWNLOAD, {"fileId": file_id}, "Download-Link"
                )
            except mw.MyWhooshHttpError as exc:
                if exc.status_code in {401, 403}:
                    set_connection_status(
                        tenant_id=authenticated_user["tenant_id"],
                        principal_id=authenticated_user["principal_id"],
                        mywhoosh_connected=False,
                    )
                    return _mywhoosh_login_required_response()
                raise

            if not isinstance(download_url, str):
                raise RuntimeError("MyWhoosh lieferte keinen gültigen Download-Link.")

            with tempfile.TemporaryDirectory(prefix="mywhoosh-sync-") as temporary_directory:
                fit_path = Path(temporary_directory) / f"{file_id}.fit"
                stage = "download_fit"
                mw.download_fit(download_url, fit_path)
                original_fit_bytes = fit_path.read_bytes()
                file_size = len(original_fit_bytes)
                file_hash = hashlib.sha256(original_fit_bytes).hexdigest()

                stage = "acquire_upload_lock"
                lock_result = acquire_upload_lock(
                    user_id=user_id, file_hash=file_hash, file_size=file_size
                )
                if lock_result == "completed":
                    logging.info(
                        "Sync skipped because upload already exists. "
                        "sync_id=%s user_id=%s file_size=%s",
                        sync_id, user_id, file_size,
                    )
                    return func.HttpResponse(
                        "Synchronisierung übersprungen. Die neueste FIT-Datei wurde für "
                        "diesen Benutzer bereits erfolgreich verarbeitet. "
                        f"{activity_count} MyWhoosh-Aktivitäten gefunden. "
                        f"FIT-Datei: {file_size} Bytes.",
                        status_code=200,
                    )
                if lock_result == "busy":
                    return func.HttpResponse(
                        "Synchronisierung läuft für diese Aktivität bereits. "
                        "Kein weiterer Upload gestartet.", status_code=409,
                    )
                if lock_result == "stale":
                    return func.HttpResponse(
                        "Eine ältere unvollständige Synchronisierung blockiert diese "
                        "Aktivität. Der Eintrag muss kontrolliert geprüft werden.",
                        status_code=409,
                    )
                if lock_result != "acquired":
                    raise RuntimeError("Unbekanntes Ergebnis der Upload-Sperre.")

                locked_file_hash = file_hash

                if _is_setting_enabled("ENABLE_GARMIN_FIT_COMPATIBILITY", default=False):
                    stage = "create_garmin_compatible_fit"
                    upload_fit_bytes, compatibility_result = make_garmin_compatible_fit(
                        original_fit_bytes, user_id=user_id
                    )
                    fit_path.write_bytes(upload_fit_bytes)
                    logging.info(
                        "Garmin-compatible FIT created. sync_id=%s user_id=%s "
                        "record_count=%s input_size=%s output_size=%s",
                        sync_id, user_id, compatibility_result.record_count,
                        compatibility_result.input_size, compatibility_result.output_size,
                    )
                else:
                    logging.info(
                        "Garmin FIT compatibility processing is disabled. "
                        "sync_id=%s user_id=%s", sync_id, user_id,
                    )

                stage = "load_garmin_session"
                with materialize_garmin_session(user_id) as garmin_session_root:
                    token_directory = garmin_session_root / "garmin_tokens"
                    if not token_directory.is_dir():
                        raise RuntimeError("Temporäres Garmin-Tokenverzeichnis fehlt.")

                    def reject_mfa():
                        raise GarminReconnectRequiredError("Garmin requires reconnection.")

                    garmin_api = Garmin(prompt_mfa=reject_mfa)
                    stage = "garmin_login"
                    try:
                        garmin_api.login(str(token_directory))
                    except (GarminConnectAuthenticationError, GarminReconnectRequiredError):
                        set_connection_status(
                            tenant_id=authenticated_user["tenant_id"],
                            principal_id=authenticated_user["principal_id"],
                            garmin_connected=False,
                        )
                        if locked_file_hash is not None:
                            release_upload_lock(user_id, locked_file_hash)
                            locked_file_hash = None
                        logging.warning(
                            "Garmin session requires reconnection. sync_id=%s user_id=%s",
                            sync_id, user_id,
                        )
                        return _garmin_login_required_response(sync_id)

                    stage = "garmin_upload"
                    try:
                        upload_response = garmin_api.upload_activity(str(fit_path))
                    except GarminConnectAuthenticationError:
                        set_connection_status(
                            tenant_id=authenticated_user["tenant_id"],
                            principal_id=authenticated_user["principal_id"],
                            garmin_connected=False,
                        )
                        if locked_file_hash is not None:
                            release_upload_lock(user_id, locked_file_hash)
                            locked_file_hash = None
                        logging.warning(
                            "Garmin authentication failed during upload. "
                            "sync_id=%s user_id=%s", sync_id, user_id,
                        )
                        return _garmin_login_required_response(sync_id)
                    except GarminConnectTooManyRequestsError as exc:
                        raise RuntimeError(
                            "Garmin hat den Upload vorübergehend begrenzt. "
                            "Das Upload-Ergebnis ist unklar."
                        ) from exc
                    except GarminConnectConnectionError as exc:
                        if _is_garmin_duplicate_activity_error(exc):
                            status = "duplicate"
                            garmin_activity_id = None
                            logging.info(
                                "Garmin confirmed duplicate activity. "
                                "sync_id=%s user_id=%s file_size=%s",
                                sync_id, user_id, file_size,
                            )
                        else:
                            raise RuntimeError(
                                "Garmin-Upload fehlgeschlagen oder das Ergebnis ist unklar. "
                                "Die Aktivität wurde nicht als synchronisiert gespeichert."
                            ) from exc
                    else:
                        status, garmin_activity_id = import_result(upload_response)

                stage = "save_upload_history"
                save_upload(
                    user_id=user_id,
                    file_hash=file_hash,
                    status=status,
                    file_size=file_size,
                    garmin_activity_id=garmin_activity_id or None,
                )
                locked_file_hash = None
                stage = "completed"
                logging.info(
                    "Sync completed. sync_id=%s user_id=%s status=%s file_size=%s",
                    sync_id, user_id, status, file_size,
                )

        result_text = (
            "Garmin hat die Aktivität als bereits vorhanden bestätigt."
            if status == "duplicate"
            else "Garmin hat die Aktivität erfolgreich importiert."
        )
        return func.HttpResponse(
            "Synchronisierung abgeschlossen. "
            f"{result_text} {activity_count} MyWhoosh-Aktivitäten gefunden. "
            f"FIT-Datei: {file_size} Bytes. Status: {status}.",
            status_code=200,
        )

    except PermissionError:
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account is disabled.",
                "error_id": sync_id,
            },
            403,
        )
    except FitCompatibilityError as exc:
        if locked_file_hash is not None and user_id is not None:
            try:
                release_upload_lock(user_id, locked_file_hash)
                locked_file_hash = None
            except Exception:
                logging.exception(
                    "Upload lock could not be released after FIT processing failure. "
                    "sync_id=%s user_id=%s", sync_id, user_id,
                )
        logging.exception(
            "FIT compatibility processing failed. sync_id=%s user_id=%s "
            "stage=%s exception_type=%s",
            sync_id, user_id, stage, type(exc).__name__,
        )
        return _json_response(
            {
                "code": "FIT_COMPATIBILITY_FAILED",
                "message": "The activity file could not be prepared for Garmin.",
                "error_id": sync_id,
            },
            500,
        )
    except Exception as exc:
        if locked_file_hash is not None and user_id is not None:
            try:
                release_upload_lock(user_id, locked_file_hash)
                locked_file_hash = None
            except Exception:
                logging.exception(
                    "Upload lock could not be released. sync_id=%s user_id=%s",
                    sync_id, user_id,
                )
        logging.exception(
            "Sync failed. sync_id=%s user_id=%s stage=%s exception_type=%s",
            sync_id, user_id, stage, type(exc).__name__,
        )
        return _json_response(
            {
                "code": "SYNC_FAILED",
                "message": "Synchronization failed. Please try again.",
                "error_id": sync_id,
            },
            500,
        )


@app.route(route="mywhoosh-login", methods=["POST"])
def mywhoosh_login(req: func.HttpRequest) -> func.HttpResponse:
    login_id = str(uuid.uuid4())
    stage = "request_received"
    user_id = None
    password = None

    try:
        authenticated_user, app_user = _resolve_active_app_user(req)
        user_id = app_user["InternalUserId"]

        try:
            request_body = req.get_json()
        except ValueError:
            request_body = None

        if not isinstance(request_body, dict):
            return _json_response(
                {
                    "code": "INVALID_REQUEST",
                    "message": "Email and password are required.",
                },
                400,
            )

        email = str(request_body.get("email", "")).strip()
        password = request_body.get("password")

        if (
            not email
            or len(email) > 254
            or not isinstance(password, str)
            or not password
            or len(password) > 1024
        ):
            return _json_response(
                {
                    "code": "INVALID_CREDENTIALS_INPUT",
                    "message": "Email and password are required.",
                },
                400,
            )

        stage = "check_login_rate_limit"
        try:
            check_mywhoosh_login_allowed(user_id)
        except LoginRateLimitExceeded as exc:
            return func.HttpResponse(
                body=json.dumps(
                    {
                        "code": "LOGIN_RATE_LIMITED",
                        "message": (
                            "Too many sign-in attempts. "
                            "Please try again later."
                        ),
                        "retry_after_seconds": exc.retry_after_seconds,
                    },
                    separators=(",", ":"),
                ),
                status_code=429,
                headers={"Retry-After": str(exc.retry_after_seconds)},
                mimetype="application/json",
            )

        stage = "mywhoosh_password_login"
        with requests.Session() as session:
            session.headers.update(
                {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                }
            )
            try:
                access_token = mw.password_login(
                    session,
                    email,
                    password,
                )
            except mw.MyWhooshAlreadyLoggedInError:
                password = None
                raise
            except Exception:
                password = None
                record_mywhoosh_login_failure(user_id)
                raise

        password = None

        if not isinstance(access_token, str) or not access_token.strip():
            record_mywhoosh_login_failure(user_id)
            raise RuntimeError("MyWhoosh lieferte keinen Access-Token.")

        clear_mywhoosh_login_failures(user_id)
        stage = "save_mywhoosh_secret"
        save_mywhoosh_credentials(
            user_id=user_id,
            email=email,
            access_token=access_token,
        )

        stage = "update_user_status"
        set_connection_status(
            tenant_id=authenticated_user["tenant_id"],
            principal_id=authenticated_user["principal_id"],
            mywhoosh_connected=True,
        )

        logging.info(
            "MyWhoosh connection completed. login_id=%s user_id=%s",
            login_id,
            user_id,
        )
        return _json_response(
            {
                "connected": True,
                "message": "MyWhoosh was connected successfully.",
            },
            200,
        )

    except mw.MyWhooshAlreadyLoggedInError:
        password = None
        logging.warning(
            "MyWhoosh connection blocked by an existing device session. "
            "login_id=%s user_id=%s",
            login_id,
            user_id,
        )
        return _json_response(
            {
                "code": "MYWHOOSH_ACTIVE_SESSION",
                "message": (
                    "You are already signed in to MyWhoosh on another device. "
                    "Open the MyWhoosh app, go to your account settings, sign "
                    "out all active devices, and then try connecting RideBridge "
                    "again."
                ),
                "error_id": login_id,
            },
            409,
        )

    except PermissionError:
        password = None
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account is disabled.",
            },
            403,
        )
    except Exception as exc:
        password = None
        logging.exception(
            "MyWhoosh connection failed. "
            "login_id=%s stage=%s exception_type=%s",
            login_id,
            stage,
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "MYWHOOSH_LOGIN_FAILED",
                "message": (
                    "MyWhoosh sign-in failed. Please verify the credentials."
                ),
                "error_id": login_id,
            },
            401,
        )


@app.route(route="garmin-login/start", methods=["POST"])
def garmin_login_start(req: func.HttpRequest) -> func.HttpResponse:
    login_id = str(uuid.uuid4())
    stage = "request_received"
    user_id = None
    password = None

    try:
        authenticated_user, app_user = _resolve_active_app_user(req)
        user_id = app_user["InternalUserId"]

        try:
            request_body = req.get_json()
        except ValueError:
            request_body = None

        if not isinstance(request_body, dict):
            return _json_response(
                {
                    "code": "INVALID_REQUEST",
                    "message": "Garmin email and password are required.",
                },
                400,
            )

        email = str(request_body.get("email", "")).strip()
        password = request_body.get("password")

        if (
            not email
            or len(email) > 254
            or not isinstance(password, str)
            or not password
            or len(password) > 1024
        ):
            return _json_response(
                {
                    "code": "INVALID_CREDENTIALS_INPUT",
                    "message": "Garmin email and password are required.",
                },
                400,
            )

        stage = "check_garmin_login_rate_limit"
        try:
            check_garmin_login_allowed(user_id)
        except LoginRateLimitExceeded as exc:
            logging.warning(
                "Garmin login rate limited. "
                "login_id=%s user_id=%s retry_after=%s",
                login_id,
                user_id,
                exc.retry_after_seconds,
            )
            return func.HttpResponse(
                body=json.dumps(
                    {
                        "code": "GARMIN_LOGIN_RATE_LIMITED",
                        "message": (
                            "Too many Garmin sign-in attempts. "
                            "Please try again later."
                        ),
                        "retry_after_seconds": exc.retry_after_seconds,
                    },
                    separators=(",", ":"),
                ),
                status_code=429,
                headers={"Retry-After": str(exc.retry_after_seconds)},
                mimetype="application/json",
            )

        stage = "clear_previous_mfa"
        delete_pending_garmin_mfa(user_id)

        stage = "garmin_login"
        with tempfile.TemporaryDirectory(
            prefix="garmin-login-"
        ) as temporary_directory:
            token_directory = Path(temporary_directory) / "garmin_tokens"
            token_directory.mkdir(parents=True, exist_ok=True)

            garmin_api = Garmin(
                email=email,
                password=password,
                return_on_mfa=True,
                retry_attempts=1,
                retry_min_wait=1.0,
                retry_max_wait=2.0,
            )
            login_status, client_state = garmin_api.login(
                str(token_directory)
            )
            password = None

            if login_status == "needs_mfa":
                stage = "save_pending_mfa"
                if not isinstance(client_state, dict):
                    raise RuntimeError("Garmin returned an invalid MFA state.")

                clear_garmin_login_failures(user_id)
                save_pending_garmin_mfa(user_id, client_state)

                logging.info(
                    "Garmin MFA required. login_id=%s user_id=%s",
                    login_id,
                    user_id,
                )
                return _json_response(
                    {
                        "status": "mfa_required",
                        "message": "Garmin verification code is required.",
                        "expires_in_seconds": 600,
                    },
                    202,
                )

            stage = "persist_session"
            if not (token_directory / "garmin_tokens.json").is_file():
                garmin_api.client.dump(str(token_directory))

            clear_garmin_login_failures(user_id)
            save_garmin_session_directory(user_id, token_directory)

        stage = "update_user_status"
        set_connection_status(
            tenant_id=authenticated_user["tenant_id"],
            principal_id=authenticated_user["principal_id"],
            garmin_connected=True,
        )

        logging.info(
            "Garmin connection completed without MFA. "
            "login_id=%s user_id=%s",
            login_id,
            user_id,
        )
        return _json_response(
            {
                "status": "connected",
                "connected": True,
                "message": "Garmin was connected successfully.",
            },
            200,
        )

    except GarminConnectTooManyRequestsError:
        password = None
        if user_id is not None:
            try:
                record_garmin_login_failure(user_id)
            except Exception:
                logging.exception(
                    "Garmin rate-limit event could not be recorded. "
                    "login_id=%s user_id=%s",
                    login_id,
                    user_id,
                )

        logging.warning(
            "Garmin rate limit encountered. login_id=%s stage=%s",
            login_id,
            stage,
        )
        return func.HttpResponse(
            body=json.dumps(
                {
                    "code": "GARMIN_RATE_LIMITED",
                    "message": (
                        "Garmin temporarily blocked sign-in attempts. "
                        "Please try again later."
                    ),
                    "error_id": login_id,
                },
                separators=(",", ":"),
            ),
            status_code=429,
            headers={"Retry-After": "900"},
            mimetype="application/json",
        )

    except GarminConnectAuthenticationError as exc:
        password = None
        if user_id is not None:
            try:
                record_garmin_login_failure(user_id)
            except Exception:
                logging.exception(
                    "Garmin login failure counter could not be updated. "
                    "login_id=%s user_id=%s",
                    login_id,
                    user_id,
                )

        logging.warning(
            "Garmin sign-in rejected. "
            "login_id=%s stage=%s exception_type=%s",
            login_id,
            stage,
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "GARMIN_LOGIN_FAILED",
                "message": (
                    "Garmin sign-in failed. Please verify the credentials."
                ),
                "error_id": login_id,
            },
            401,
        )

    except GarminConnectConnectionError as exc:
        password = None
        logging.warning(
            "Garmin connection error. "
            "login_id=%s stage=%s exception_type=%s",
            login_id,
            stage,
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "GARMIN_CONNECTION_FAILED",
                "message": "Garmin could not be reached. Please try again later.",
                "error_id": login_id,
            },
            502,
        )

    except PermissionError:
        password = None
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account is disabled.",
            },
            403,
        )

    except Exception as exc:
        password = None
        logging.exception(
            "Garmin connection start failed. "
            "login_id=%s stage=%s exception_type=%s",
            login_id,
            stage,
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "GARMIN_LOGIN_FAILED",
                "message": "Garmin sign-in failed.",
                "error_id": login_id,
            },
            500,
        )


@app.route(route="garmin-login/complete", methods=["POST"])
def garmin_login_complete(req: func.HttpRequest) -> func.HttpResponse:
    login_id = str(uuid.uuid4())
    stage = "request_received"
    user_id = None
    mfa_code = None

    try:
        authenticated_user, app_user = _resolve_active_app_user(req)
        user_id = app_user["InternalUserId"]

        try:
            request_body = req.get_json()
        except ValueError:
            request_body = None

        mfa_code = (
            str(request_body.get("mfa_code", "")).strip()
            if isinstance(request_body, dict)
            else ""
        )

        if not mfa_code or len(mfa_code) > 16 or not mfa_code.isdigit():
            return _json_response(
                {
                    "code": "INVALID_MFA_CODE",
                    "message": "A valid Garmin verification code is required.",
                },
                400,
            )

        stage = "load_pending_mfa"
        client_state = get_pending_garmin_mfa(user_id)

        stage = "resume_garmin_login"
        with tempfile.TemporaryDirectory(
            prefix="garmin-mfa-"
        ) as temporary_directory:
            token_directory = Path(temporary_directory) / "garmin_tokens"
            token_directory.mkdir(parents=True, exist_ok=True)

            garmin_api = Garmin(
                retry_attempts=1,
                retry_min_wait=1.0,
                retry_max_wait=2.0,
            )
            garmin_api.resume_login(client_state, mfa_code)
            mfa_code = None

            stage = "dump_garmin_session"
            garmin_api.client.dump(str(token_directory))

            stage = "save_garmin_session"
            save_garmin_session_directory(user_id, token_directory)

        stage = "clear_pending_mfa"
        delete_pending_garmin_mfa(user_id)

        stage = "update_user_status"
        set_connection_status(
            tenant_id=authenticated_user["tenant_id"],
            principal_id=authenticated_user["principal_id"],
            garmin_connected=True,
        )

        logging.info(
            "Garmin connection completed with MFA. "
            "login_id=%s user_id=%s",
            login_id,
            user_id,
        )
        return _json_response(
            {
                "status": "connected",
                "connected": True,
                "message": "Garmin was connected successfully.",
            },
            200,
        )

    except GarminConnectTooManyRequestsError:
        mfa_code = None
        if user_id is not None:
            try:
                delete_pending_garmin_mfa(user_id)
            except Exception:
                logging.exception(
                    "Garmin pending MFA state could not be cleared "
                    "after rate limiting."
                )

        return func.HttpResponse(
            body=json.dumps(
                {
                    "code": "GARMIN_RATE_LIMITED",
                    "message": (
                        "Garmin temporarily blocked verification. "
                        "Start the Garmin connection again later."
                    ),
                    "error_id": login_id,
                },
                separators=(",", ":"),
            ),
            status_code=429,
            headers={"Retry-After": "900"},
            mimetype="application/json",
        )

    except GarminConnectAuthenticationError:
        mfa_code = None
        if user_id is not None:
            try:
                delete_pending_garmin_mfa(user_id)
            except Exception:
                logging.exception(
                    "Garmin pending MFA state could not be cleared "
                    "after authentication failure."
                )

        return _json_response(
            {
                "code": "GARMIN_MFA_FAILED",
                "message": (
                    "Garmin verification failed. "
                    "Please start the Garmin connection again."
                ),
                "error_id": login_id,
            },
            401,
        )

    except PermissionError:
        mfa_code = None
        return _json_response(
            {
                "code": "USER_DISABLED",
                "message": "The RideBridge account is disabled.",
            },
            403,
        )

    except Exception as exc:
        mfa_code = None
        logging.exception(
            "Garmin connection completion failed. "
            "login_id=%s stage=%s exception_type=%s",
            login_id,
            stage,
            type(exc).__name__,
        )
        return _json_response(
            {
                "code": "GARMIN_MFA_FAILED",
                "message": "Garmin verification failed.",
                "error_id": login_id,
            },
            500,
        )
