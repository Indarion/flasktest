import { PublicClientApplication } from "@azure/msal-browser";
import { apiConfig, loginRequest, msalConfig } from "./authConfig.js";
import "./style.css";

const $ = (selector) => document.querySelector(selector);

const signedOutView = $("#signed-out-view");
const signedInView = $("#signed-in-view");
const accountName = $("#account-name");
const statusBox = $("#status");

const signInButton = $("#sign-in-button");
const signOutButton = $("#sign-out-button");
const syncButton = $("#sync-button");

const mywhooshState = $("#mywhoosh-state");
const garminState = $("#garmin-state");

const showMyWhooshFormButton = $("#show-mywhoosh-form-button");
const mywhooshLoginForm = $("#mywhoosh-login-form");
const mywhooshEmail = $("#mywhoosh-email");
const mywhooshPassword = $("#mywhoosh-password");
const connectMyWhooshButton = $("#connect-mywhoosh-button");
const cancelMyWhooshButton = $("#cancel-mywhoosh-button");

const showGarminFormButton = $("#show-garmin-form-button");
const garminLoginForm = $("#garmin-login-form");
const garminCredentialsFields = $("#garmin-credentials-fields");
const garminMfaFields = $("#garmin-mfa-fields");
const garminEmail = $("#garmin-email");
const garminPassword = $("#garmin-password");
const garminMfaCode = $("#garmin-mfa-code");
const connectGarminButton = $("#connect-garmin-button");
const cancelGarminButton = $("#cancel-garmin-button");

const msalInstance = new PublicClientApplication(msalConfig);

const showDangerZoneButton = $(
    "#show-danger-zone-button",
);
const dangerZone = $("#danger-zone");
const deleteAccountForm = $("#delete-account-form");
const deleteAccountConfirmation = $(
    "#delete-account-confirmation",
);
const deleteAccountButton = $("#delete-account-button");
const cancelDeleteAccountButton = $(
    "#cancel-delete-account-button",
);

let currentProfile = null;
let loginCooldownTimer = null;
let garminMfaPending = false;

function showStatus(message, type = "info") {
    statusBox.textContent = message;
    statusBox.className = `status ${type}`;
    statusBox.hidden = false;
}

function clearStatus() {
    statusBox.textContent = "";
    statusBox.hidden = true;
}

function canSynchronize() {
    return Boolean(
        currentProfile?.mywhoosh_connected &&
            currentProfile?.garmin_connected,
    );
}

function setBusy(busy) {
    const controls = [
        signInButton,
        signOutButton,
        showMyWhooshFormButton,
        connectMyWhooshButton,
        cancelMyWhooshButton,
        showGarminFormButton,
        connectGarminButton,
        cancelGarminButton,
        showDangerZoneButton,
        deleteAccountButton,
        cancelDeleteAccountButton,
    ];

    for (const control of controls) {
        control.disabled = busy;
    }

    syncButton.disabled = busy || !canSynchronize();
}

function getCurrentAccount() {
    const activeAccount = msalInstance.getActiveAccount();

    if (activeAccount) {
        return activeAccount;
    }

    const accounts = msalInstance.getAllAccounts();

    if (accounts.length === 1) {
        msalInstance.setActiveAccount(accounts[0]);
        return accounts[0];
    }

    return null;
}

function updateConnectionUi() {
    const mywhooshConnected = Boolean(currentProfile?.mywhoosh_connected);
    const garminConnected = Boolean(currentProfile?.garmin_connected);

    mywhooshState.textContent = mywhooshConnected
        ? "Connected"
        : "Not connected";
    mywhooshState.className =
        `connection-state ${mywhooshConnected ? "connected" : ""}`;

    garminState.textContent = garminConnected
        ? "Connected"
        : "Not connected";
    garminState.className =
        `connection-state ${garminConnected ? "connected" : ""}`;

    showMyWhooshFormButton.textContent = mywhooshConnected
        ? "Reconnect MyWhoosh"
        : "Connect MyWhoosh";

    showGarminFormButton.textContent = garminConnected
        ? "Reconnect Garmin"
        : "Connect Garmin";

    syncButton.disabled = !canSynchronize();
}

function updateUi() {
    const account = getCurrentAccount();
    const signedIn = account !== null;

    signedOutView.hidden = signedIn;
    signedInView.hidden = !signedIn;
    accountName.textContent =
        account?.name || account?.username || "RideBridge user";

    if (!signedIn) {
        currentProfile = null;
        mywhooshLoginForm.hidden = true;
        garminLoginForm.hidden = true;
    }

    updateConnectionUi();
}

async function acquireApiToken(account) {
    return await msalInstance.acquireTokenSilent({
        ...loginRequest,
        account,
    });
}

async function authenticatedFetch(url, options = {}) {
    const account = getCurrentAccount();

    if (!account) {
        throw new Error("Please sign in first.");
    }

    const token = await acquireApiToken(account);

    return await fetch(url, {
        ...options,
        headers: {
            ...(options.headers || {}),
            Authorization: `Bearer ${token.accessToken}`,
        },
    });
}

async function loadUserProfile({ announce = false } = {}) {
    const response = await authenticatedFetch(apiConfig.meUrl, {
        method: "GET",
    });
    const result = await response.json();

    if (!response.ok) {
        throw new Error(
            result?.message || "User profile initialization failed.",
        );
    }

    currentProfile = result;
    updateConnectionUi();

    if (announce) {
        showStatus(`User initialized. Plan: ${result.plan}.`, "success");
    }
}

async function signIn() {
    clearStatus();
    setBusy(true);

    try {
        await msalInstance.loginRedirect(loginRequest);
    } catch (error) {
        console.error("Sign-in failed:", error.errorCode || error.name);
        showStatus(
            `Sign-in failed: ${
                error.errorCode || error.name || "unknown_error"
            }`,
            "error",
        );
        setBusy(false);
    }
}

async function signOut() {
    clearStatus();
    setBusy(true);

    try {
        await msalInstance.logoutRedirect({
            account: getCurrentAccount(),
            postLogoutRedirectUri: msalConfig.auth.postLogoutRedirectUri,
        });
    } catch (error) {
        console.error("Sign-out failed:", error.errorCode || error.name);
        showStatus("Sign-out failed. Please try again.", "error");
        setBusy(false);
    }
}

function startLoginCooldown(seconds) {
    if (loginCooldownTimer) {
        clearInterval(loginCooldownTimer);
    }

    let remaining = Math.max(1, Number(seconds) || 1);
    connectMyWhooshButton.disabled = true;

    const render = () => {
        connectMyWhooshButton.textContent = `Try again in ${remaining}s`;
    };

    render();

    loginCooldownTimer = setInterval(() => {
        remaining -= 1;

        if (remaining <= 0) {
            clearInterval(loginCooldownTimer);
            loginCooldownTimer = null;
            connectMyWhooshButton.textContent = "Connect";
            connectMyWhooshButton.disabled = false;
        } else {
            render();
        }
    }, 1000);
}

function showMyWhooshForm() {
    clearStatus();
    mywhooshLoginForm.hidden = false;
    mywhooshEmail.focus();
}

function hideMyWhooshForm() {
    mywhooshPassword.value = "";
    mywhooshLoginForm.reset();
    mywhooshLoginForm.hidden = true;
    connectMyWhooshButton.textContent = "Connect";
}

async function connectMyWhoosh(event) {
    event.preventDefault();
    clearStatus();

    if (!mywhooshLoginForm.reportValidity()) {
        return;
    }

    const email = mywhooshEmail.value.trim();
    const password = mywhooshPassword.value;

    setBusy(true);
    showStatus("Connecting MyWhoosh…");

    try {
        const response = await authenticatedFetch(
            apiConfig.mywhooshLoginUrl,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            },
        );

        mywhooshPassword.value = "";
        const result = await response.json().catch(() => ({}));

        if (response.status === 429) {
            const retryAfter = Number(
                response.headers.get("Retry-After") ||
                    result?.retry_after_seconds ||
                    5,
            );

            startLoginCooldown(retryAfter);
            showStatus(
                result?.message ||
                    "Too many sign-in attempts. Please try again later.",
                "warning",
            );
            return;
        }

        if (!response.ok) {
            throw new Error(
                `${result?.message || "MyWhoosh sign-in failed."}${
                    result?.error_id
                        ? ` Error ID: ${result.error_id}`
                        : ""
                }`,
            );
        }

        hideMyWhooshForm();
        await loadUserProfile();
        showStatus("MyWhoosh was connected successfully.", "success");
    } catch (error) {
        mywhooshPassword.value = "";
        showStatus(error.message || "MyWhoosh sign-in failed.", "error");
    } finally {
        if (!loginCooldownTimer) {
            setBusy(false);
        }
    }
}

function setGarminMfaMode(enabled) {
    garminMfaPending = enabled;
    garminCredentialsFields.hidden = enabled;
    garminMfaFields.hidden = !enabled;
    garminEmail.required = !enabled;
    garminPassword.required = !enabled;
    garminMfaCode.required = enabled;
    connectGarminButton.textContent = enabled ? "Verify code" : "Connect";

    if (enabled) {
        garminMfaCode.focus();
    } else {
        garminEmail.focus();
    }
}

function showGarminForm() {
    clearStatus();
    garminLoginForm.hidden = false;
    setGarminMfaMode(false);
}

function hideGarminForm() {
    garminPassword.value = "";
    garminMfaCode.value = "";
    garminLoginForm.reset();
    garminLoginForm.hidden = true;
    setGarminMfaMode(false);
}

async function startGarminLogin() {
    const email = garminEmail.value.trim();
    const password = garminPassword.value;

    const response = await authenticatedFetch(
        apiConfig.garminLoginStartUrl,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }),
        },
    );

    garminPassword.value = "";
    const result = await response.json().catch(() => ({}));

    if (response.status === 202 && result?.status === "mfa_required") {
        setGarminMfaMode(true);
        showStatus(
            "Garmin verification code is required. " +
                "Check your configured Garmin MFA method.",
            "warning",
        );
        return;
    }

    if (response.status === 429) {
        const retryAfter = Number(
            response.headers.get("Retry-After") ||
                result?.retry_after_seconds ||
                900,
        );

        throw new Error(
            `${
                result?.message ||
                "Garmin temporarily blocked sign-in attempts."
            } Try again in about ${Math.ceil(retryAfter / 60)} minutes.`,
        );
    }

    if (!response.ok) {
        throw new Error(
            `${result?.message || "Garmin sign-in failed."}${
                result?.error_id ? ` Error ID: ${result.error_id}` : ""
            }`,
        );
    }

    hideGarminForm();
    await loadUserProfile();
    showStatus("Garmin was connected successfully.", "success");
}

async function completeGarminLogin() {
    const mfaCode = garminMfaCode.value.trim();

    const response = await authenticatedFetch(
        apiConfig.garminLoginCompleteUrl,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ mfa_code: mfaCode }),
        },
    );

    garminMfaCode.value = "";
    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
        setGarminMfaMode(false);
        throw new Error(
            `${
                result?.message ||
                "Garmin verification failed. " +
                    "Start the Garmin connection again."
            }${
                result?.error_id ? ` Error ID: ${result.error_id}` : ""
            }`,
        );
    }

    hideGarminForm();
    await loadUserProfile();
    showStatus("Garmin was connected successfully.", "success");
}

async function connectGarmin(event) {
    event.preventDefault();
    clearStatus();

    if (!garminLoginForm.reportValidity()) {
        return;
    }

    setBusy(true);
    showStatus(
        garminMfaPending
            ? "Verifying Garmin code…"
            : "Connecting Garmin…",
    );

    try {
        if (garminMfaPending) {
            await completeGarminLogin();
        } else {
            await startGarminLogin();
        }
    } catch (error) {
        garminPassword.value = "";
        garminMfaCode.value = "";
        showStatus(error.message || "Garmin connection failed.", "error");
    } finally {
        setBusy(false);
    }
}

function showDangerZone() {
    clearStatus();

    showDangerZoneButton.hidden = true;
    dangerZone.hidden = false;

    deleteAccountConfirmation.value = "";
    deleteAccountButton.disabled = true;
    deleteAccountConfirmation.focus();
}


function hideDeleteAccountForm() {
    deleteAccountConfirmation.value = "";
    deleteAccountButton.disabled = true;
    deleteAccountForm.hidden = true;
}


function updateDeleteConfirmation() {
    deleteAccountButton.disabled =
        deleteAccountConfirmation.value !== "DELETE";
}


async function deleteAccount(event) {
    event.preventDefault();
    clearStatus();

    if (deleteAccountConfirmation.value !== "DELETE") {
        showStatus(
            "Type DELETE exactly to confirm account deletion.",
            "warning",
        );
        return;
    }

    const confirmed = window.confirm(
        "Delete all RideBridge data and saved connections? " +
            "This action cannot be undone.",
    );

    if (!confirmed) {
        return;
    }

    setBusy(true);
    showStatus("Deleting RideBridge account…", "warning");

    try {
        const response = await authenticatedFetch(
            apiConfig.accountDeleteUrl,
            {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    confirmation: "DELETE",
                }),
            },
        );

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(
                [
                    result?.message ||
                        "The account could not be deleted.",
                    result?.error_id
                        ? `Error ID: ${result.error_id}`
                        : "",
                ]
                    .filter(Boolean)
                    .join(" "),
            );
        }

        const deletionReference = result?.deletion_id;

        currentProfile = null;
        hideDeleteAccountForm();

        const referenceText = deletionReference
            ? ` Deletion reference: ${deletionReference}.`
            : "";

        showStatus(
            "Your RideBridge data was deleted. " +
                "Your sign-in identity will be deleted shortly." +
                referenceText +
                " Keep this reference if you need confirmation or support.",
            "success",
        );

        if (deletionReference) {
            try {
                await navigator.clipboard.writeText(
                    deletionReference,
                );

                showStatus(
                    "Your RideBridge data was deleted. " +
                        "Your sign-in identity will be deleted shortly. " +
                        `Deletion reference: ${deletionReference}. ` +
                        "The reference was copied to your clipboard.",
                    "success",
                );
            } catch {
                // Clipboard access may be blocked.
                // The reference remains visible.
            }
        }

        window.setTimeout(async () => {
            try {
                await msalInstance.logoutRedirect({
                    account: getCurrentAccount(),
                    postLogoutRedirectUri:
                        msalConfig.auth.postLogoutRedirectUri,
                });
            } catch (error) {
                console.error(
                    "Logout after deletion failed:",
                    error.name,
                );
            }
        }, 15000);


    } catch (error) {
        showStatus(
            error.message ||
                "The account could not be deleted completely.",
            "error",
        );

        setBusy(false);
    }
}

async function synchronize() {
    clearStatus();

    if (!getCurrentAccount()) {
        showStatus(
            "Please sign in before starting synchronization.",
            "error",
        );
        return;
    }

    if (!canSynchronize()) {
        showStatus(
            "Connect MyWhoosh and Garmin before synchronizing.",
            "warning",
        );
        return;
    }

    setBusy(true);
    showStatus("Synchronization is running…");

    try {
        const response = await authenticatedFetch(apiConfig.syncUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ confirmUpload: true }),
        });

        const contentType = response.headers.get("content-type") || "";
        const result = contentType.includes("application/json")
            ? await response.json()
            : await response.text();

        if (
            response.status === 401 &&
            typeof result === "object" &&
            result?.code === "MYWHOOSH_LOGIN_REQUIRED"
        ) {
            currentProfile = {
                ...currentProfile,
                mywhoosh_connected: false,
            };

            updateConnectionUi();
            mywhooshLoginForm.hidden = false;
            mywhooshEmail.focus();

            showStatus(
                "Your MyWhoosh connection has expired. " +
                    "Please reconnect MyWhoosh.",
                "warning",
            );
            return;
        }

        if (
            response.status === 401 &&
            typeof result === "object" &&
            result?.code === "GARMIN_LOGIN_REQUIRED"
        ) {
            currentProfile = {
                ...currentProfile,
                garmin_connected: false,
            };

            updateConnectionUi();
            garminLoginForm.hidden = false;
            setGarminMfaMode(false);

            showStatus(
                "Your Garmin connection has expired. " +
                    "Please reconnect Garmin.",
                "warning",
            );
            return;
        }

        if (!response.ok) {
            const message =
                typeof result === "string"
                    ? result
                    : [
                          result?.message || "Synchronization failed.",
                          result?.error_id
                              ? `Error ID: ${result.error_id}`
                              : "",
                      ]
                          .filter(Boolean)
                          .join(" ");

            throw new Error(message);
        }

        showStatus(
            typeof result === "string"
                ? result
                : "Synchronization completed.",
            "success",
        );
    } catch (error) {
        showStatus(
            error.message ||
                "Synchronization failed. Please try again.",
            "error",
        );
    } finally {
        setBusy(false);
    }
}

async function initialize() {
    await msalInstance.initialize();

    const redirect = await msalInstance.handleRedirectPromise();

    if (redirect?.account) {
        msalInstance.setActiveAccount(redirect.account);
    }

    updateUi();

    if (getCurrentAccount()) {
        try {
            await loadUserProfile({ announce: true });
        } catch (error) {
            showStatus(
                error.message || "User profile initialization failed.",
                "error",
            );
        }
    }
}

signInButton.addEventListener("click", signIn);
signOutButton.addEventListener("click", signOut);
syncButton.addEventListener("click", synchronize);

showMyWhooshFormButton.addEventListener("click", showMyWhooshForm);
cancelMyWhooshButton.addEventListener("click", hideMyWhooshForm);
mywhooshLoginForm.addEventListener("submit", connectMyWhoosh);

showGarminFormButton.addEventListener("click", showGarminForm);
cancelGarminButton.addEventListener("click", hideGarminForm);
garminLoginForm.addEventListener("submit", connectGarmin);

showDangerZoneButton.addEventListener(
    "click",
    showDangerZone,
);

cancelDeleteAccountButton.addEventListener(
    "click",
    hideDeleteAccountForm,
);

deleteAccountConfirmation.addEventListener(
    "input",
    updateDeleteConfirmation,
);

deleteAccountForm.addEventListener(
    "submit",
    deleteAccount,
);

initialize().catch((error) => {
    console.error("Application initialization failed:", error.name);
    showStatus("RideBridge could not be initialized.", "error");
});
