"""RideBridge FIT compatibility processing.

This module rewrites only the FIT file identity fields required for Garmin
Connect compatibility. Activity measurements, laps, sessions, records, and
timestamps are not intentionally modified.
"""

from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass
from pathlib import Path

from fit_tool import EncodeMode, FitFile
from fit_tool.profile.messages.file_id_message import FileIdMessage
from fit_tool.profile.profile_type import GarminProduct, Manufacturer

# FIT serial_number is uint32. Restrict it to a stable 10-digit decimal range.
_MIN_SERIAL = 1_000_000_000
_MAX_SERIAL = 4_294_967_295
_SERIAL_RANGE = _MAX_SERIAL - _MIN_SERIAL + 1


class FitCompatibilityError(RuntimeError):
    """Raised when a FIT file cannot be safely converted."""


@dataclass(frozen=True)
class FitCompatibilityResult:
    serial_number: int
    manufacturer: int
    garmin_product: int
    input_size: int
    output_size: int
    record_count: int


def virtual_device_serial(user_id: str, pepper: str | None = None) -> int:
    """Return a stable, pseudonymous 10-digit FIT uint32 serial number.

    The same user ID and pepper always produce the same serial. The serial is
    not reversible without the secret pepper and never exceeds uint32.
    """
    normalized_user_id = user_id.strip().lower()
    if not normalized_user_id:
        raise ValueError("user_id is required")

    resolved_pepper = (
        pepper if pepper is not None else os.getenv("FIT_DEVICE_SERIAL_PEPPER", "")
    ).strip()
    if len(resolved_pepper) < 32:
        raise FitCompatibilityError(
            "FIT_DEVICE_SERIAL_PEPPER is missing or shorter than 32 characters."
        )

    digest = hmac.new(
        resolved_pepper.encode("utf-8"),
        normalized_user_id.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    value = int.from_bytes(digest[:8], byteorder="big", signed=False)
    return _MIN_SERIAL + (value % _SERIAL_RANGE)


def _message_counts(fit_file: FitFile) -> dict[str, int]:
    counts: dict[str, int] = {}
    for record in fit_file.records:
        message = record.message
        name = getattr(message, "name", None)
        if name:
            counts[name] = counts.get(name, 0) + 1
    return counts


def make_garmin_compatible_fit(
    original_fit: bytes,
    *,
    user_id: str,
    pepper: str | None = None,
) -> tuple[bytes, FitCompatibilityResult]:
    """Rewrite a FIT activity as a virtual Garmin Edge 540 activity.

    Duplicate detection must be performed on ``original_fit`` before calling
    this function. The returned bytes are intended only for the Garmin upload.
    """
    if not original_fit:
        raise FitCompatibilityError("FIT input is empty.")

    try:
        fit_file = FitFile.from_bytes(original_fit, check_crc=True)
    except Exception as exc:
        raise FitCompatibilityError("FIT input could not be parsed or failed CRC.") from exc

    before_counts = _message_counts(fit_file)
    file_id_messages = [
        record.message
        for record in fit_file.records
        if isinstance(record.message, FileIdMessage)
    ]
    if len(file_id_messages) != 1:
        raise FitCompatibilityError(
            f"Expected exactly one file_id message, found {len(file_id_messages)}."
        )

    serial_number = virtual_device_serial(user_id, pepper)
    file_id = file_id_messages[0]
    file_id.manufacturer = Manufacturer.GARMIN
    file_id.garmin_product = GarminProduct.EDGE_540
    file_id.serial_number = serial_number

    try:
        output = fit_file.to_bytes(
            check_crc=True,
            mode=EncodeMode.PRESERVE,
            strict=False,
        )
        verified = FitFile.from_bytes(output, check_crc=True)
    except Exception as exc:
        raise FitCompatibilityError("Garmin-compatible FIT encoding failed.") from exc

    after_counts = _message_counts(verified)
    if before_counts != after_counts:
        raise FitCompatibilityError("FIT message counts changed during conversion.")

    verified_file_ids = [
        record.message
        for record in verified.records
        if isinstance(record.message, FileIdMessage)
    ]
    verified_file_id = verified_file_ids[0]
    if int(verified_file_id.manufacturer) != int(Manufacturer.GARMIN.value):
        raise FitCompatibilityError("Converted FIT manufacturer verification failed.")
    if int(verified_file_id.garmin_product) != int(GarminProduct.EDGE_540.value):
        raise FitCompatibilityError("Converted FIT product verification failed.")
    if int(verified_file_id.serial_number) != serial_number:
        raise FitCompatibilityError("Converted FIT serial verification failed.")

    return output, FitCompatibilityResult(
        serial_number=serial_number,
        manufacturer=int(Manufacturer.GARMIN.value),
        garmin_product=int(GarminProduct.EDGE_540.value),
        input_size=len(original_fit),
        output_size=len(output),
        record_count=before_counts.get("record", 0),
    )


def rewrite_fit_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    user_id: str,
    pepper: str | None = None,
) -> FitCompatibilityResult:
    """File-oriented wrapper used for local regression tests."""
    source = Path(input_path)
    destination = Path(output_path)
    converted, result = make_garmin_compatible_fit(
        source.read_bytes(),
        user_id=user_id,
        pepper=pepper,
    )
    destination.write_bytes(converted)
    return result
