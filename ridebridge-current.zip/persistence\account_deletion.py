import hashlib
import os
from datetime import datetime, timezone
from functools import lru_cache

from azure.data.tables import TableClient, UpdateMode
from azure.identity import DefaultAzureCredential


@lru_cache(maxsize=1)
def _get_deletion_table_client() -> TableClient:
    endpoint = os.getenv(
        "TABLE_STORAGE_ENDPOINT",
        "",
    ).strip()

    table_name = os.getenv(
        "ACCOUNT_DELETION_TABLE",
        "",
    ).strip()

    if not endpoint:
        raise RuntimeError(
            "TABLE_STORAGE_ENDPOINT fehlt."
        )

    if not table_name:
        raise RuntimeError(
            "ACCOUNT_DELETION_TABLE fehlt."
        )

    return TableClient(
        endpoint=endpoint,
        table_name=table_name,
        credential=DefaultAzureCredential(),
    )


def _create_user_hash(
    tenant_id: str,
    internal_user_id: str,
) -> str:
    pepper = os.getenv(
        "ACCOUNT_DELETION_HASH_PEPPER",
        "",
    ).strip()

    if len(pepper) < 32:
        raise RuntimeError(
            "ACCOUNT_DELETION_HASH_PEPPER fehlt "
            "oder ist zu kurz."
        )

    source = (
        f"{pepper}:"
        f"{tenant_id.strip().lower()}:"
        f"{internal_user_id.strip().lower()}"
    )

    return hashlib.sha256(
        source.encode("utf-8")
    ).hexdigest()


def create_account_deletion_request(
    deletion_id: str,
    tenant_id: str,
    principal_id: str,
    internal_user_id: str,
) -> None:
    now = datetime.now(timezone.utc)

    normalized_tenant_id = tenant_id.strip().lower()
    normalized_principal_id = (
        principal_id.strip().lower()
    )

    entity = {
        "PartitionKey": "pending",
        "RowKey": deletion_id,
        "DeletionId": deletion_id,
        "TenantId": normalized_tenant_id,
        "PrincipalId": normalized_principal_id,
        "InternalUserId": internal_user_id,
        "InternalUserIdHash": _create_user_hash(
            normalized_tenant_id,
            internal_user_id,
        ),
        "RequestedAt": now,
        "Status": "deleting_ridebridge_data",
        "CurrentStage": "requested",
        "AttemptCount": 1,
        "LastAttemptAt": now,
        "DeletedUploadsCount": 0,
        "DeletedLoginAttemptsCount": 0,
        "MyWhooshSecretDeleted": False,
        "GarminSessionDeleted": False,
        "GarminMfaStateDeleted": False,
        "SchemaVersion": 1,
    }

    _get_deletion_table_client().create_entity(
        entity=entity
    )


def update_deletion_stage(
    deletion_id: str,
    stage: str,
) -> None:
    _get_deletion_table_client().update_entity(
        entity={
            "PartitionKey": "pending",
            "RowKey": deletion_id,
            "CurrentStage": stage,
            "LastAttemptAt": datetime.now(
                timezone.utc
            ),
        },
        mode=UpdateMode.MERGE,
    )


def mark_ridebridge_data_deleted(
    deletion_id: str,
    *,
    deleted_uploads_count: int,
    deleted_login_attempts_count: int,
    mywhoosh_secret_deleted: bool,
    garmin_session_deleted: bool,
    garmin_mfa_state_deleted: bool,
) -> None:
    now = datetime.now(timezone.utc)

    _get_deletion_table_client().update_entity(
        entity={
            "PartitionKey": "pending",
            "RowKey": deletion_id,
            "Status": "pending_identity_deletion",
            "CurrentStage": "identity_deletion",
            "RideBridgeDataDeletedAt": now,
            "DeletedUploadsCount": int(
                deleted_uploads_count
            ),
            "DeletedLoginAttemptsCount": int(
                deleted_login_attempts_count
            ),
            "MyWhooshSecretDeleted": bool(
                mywhoosh_secret_deleted
            ),
            "GarminSessionDeleted": bool(
                garmin_session_deleted
            ),
            "GarminMfaStateDeleted": bool(
                garmin_mfa_state_deleted
            ),
            "LastAttemptAt": now,
        },
        mode=UpdateMode.MERGE,
    )


def mark_deletion_failed(
    deletion_id: str,
    failed_stage: str,
    error_id: str,
) -> None:
    now = datetime.now(timezone.utc)

    _get_deletion_table_client().update_entity(
        entity={
            "PartitionKey": "pending",
            "RowKey": deletion_id,
            "Status": "deletion_failed",
            "CurrentStage": failed_stage,
            "FailedStage": failed_stage,
            "ErrorId": error_id,
            "LastAttemptAt": now,
        },
        mode=UpdateMode.MERGE,
    )