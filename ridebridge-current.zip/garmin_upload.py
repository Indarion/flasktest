"""Garmin FIT upload; no browser and no changes to the FIT file.

Pro MyWhoosh-Account gibt es einen eigenen Ordner neben diesem Skript:
  garmin_accounts/<mywhoosh-email>/garmin_tokens
  garmin_accounts/<mywhoosh-email>/uploads.json
  garmin_accounts/<mywhoosh-email>/garmin_account.json
"""

import getpass
import hashlib
import json
from pathlib import Path


try:
    BASE_DIR = Path(__file__).resolve().parent
except NameError:
    BASE_DIR = Path.cwd()


def account_dir(account):
    safe = "".join(
        character if (character.isalnum() or character in "@.-_") else "_"
        for character in account.strip().lower()
    )
    if not safe:
        raise RuntimeError("Garmin-Upload: MyWhoosh-Account (E-Mail) fehlt.")
    return BASE_DIR / "garmin_accounts" / safe


def read_state(path):
    if not path.exists():
        return {"uploads": {}}
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(state.get("uploads"), dict):
            raise ValueError()
        return state
    except (ValueError, OSError):
        raise RuntimeError(
            "Upload-Status ist unlesbar. Datei pruefen, bevor ein erneuter "
            "Upload erfolgt."
        ) from None


def save_state(path, state):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2), encoding="utf-8")
    temporary.replace(path)


def read_garmin_email(path):
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("garmin_email")
    except (OSError, ValueError, AttributeError):
        return None


def import_result(response):
    """Interpret Garmin's synchronous and asynchronous import responses.

    Returns:
        tuple[str, str]: (status, Garmin activity ID)

    An asynchronous response with a positive uploadId and no failures means
    Garmin accepted the file. The uploadId is intentionally not stored as an
    activity ID because those identifiers represent different objects.
    """
    if hasattr(response, "json"):
        response = response.json()

    if not isinstance(response, dict):
        raise RuntimeError(
            "Garmin lieferte keine auswertbare Upload-Antwort; "
            "Erfolg nicht bestaetigt."
        )

    raw = json.dumps(response, ensure_ascii=False)[:1500]
    detail = response.get("detailedImportResult")
    if not isinstance(detail, dict):
        raise RuntimeError(
            "Garmin-Upload-Antwort ohne detailedImportResult | Antwort: " + raw
        )

    successes = detail.get("successes") or []
    failures = detail.get("failures") or []

    if successes and not failures:
        first = successes[0]
        activity_id = ""
        if isinstance(first, dict):
            activity_id = str(first.get("internalId", ""))
        return "uploaded", activity_id

    codes = []
    for failure in failures:
        if not isinstance(failure, dict):
            continue
        messages = failure.get("messages") or []
        for message in messages:
            if isinstance(message, dict):
                code = str(message.get("code", "")).strip()
                if code:
                    codes.append(code)

    if failures and codes and all(code == "202" for code in codes):
        return "duplicate", ""

    upload_id = detail.get("uploadId")
    has_upload_id = (
        isinstance(upload_id, int)
        and not isinstance(upload_id, bool)
        and upload_id > 0
    )
    has_failures = isinstance(failures, list) and len(failures) > 0

    if has_upload_id and not has_failures:
        return "uploaded", ""

    raise RuntimeError(
        "Garmin hat den Import nicht bestaetigt. Fehlercodes: "
        + (", ".join(codes) or "unbekannt")
        + " | Antwort: "
        + raw
    )


def upload_fit(path, account, garmin_email=None):
    """Upload one FIT file using the Garmin session assigned to an account."""
    from garminconnect import (
        Garmin,
        GarminConnectAuthenticationError,
        GarminConnectConnectionError,
        GarminConnectTooManyRequestsError,
    )

    path = Path(path).resolve()
    with path.open("rb") as handle:
        if handle.read(12)[8:12] != b".FIT":
            raise RuntimeError("Garmin-Upload: Datei hat keine FIT-Signatur.")

    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    acc_dir = account_dir(account)
    token_dir = acc_dir / "garmin_tokens"
    state_path = acc_dir / "uploads.json"
    info_path = acc_dir / "garmin_account.json"
    token_dir.mkdir(parents=True, exist_ok=True)

    print(f"MyWhoosh-Account: {account}")
    state = read_state(state_path)
    if digest in state["uploads"]:
        print(
            "Garmin: Diese FIT-Datei wurde fuer diesen Account bereits "
            "erfolgreich verarbeitet. Kein erneuter Upload."
        )
        return

    prompt = lambda: input("Garmin MFA-Code: ").strip()
    api = None

    if any(token_dir.iterdir()):
        try:
            api = Garmin(prompt_mfa=prompt)
            api.login(str(token_dir))
            known = read_garmin_email(info_path)
            print(
                "Garmin-Sitzung wiederhergestellt"
                + (f" (Garmin-Konto: {known})." if known else ".")
            )
        except Exception:
            api = None
            print("Gespeicherte Garmin-Sitzung nicht nutzbar, neue Anmeldung noetig.")

    if api is None:
        garmin_email = garmin_email or input("E-Mail fuer Garmin eingeben: ").strip()
        password = getpass.getpass("Garmin-Passwort: ")
        api = Garmin(garmin_email, password, prompt_mfa=prompt)
        del password
        api.login(str(token_dir))
        info_path.write_text(
            json.dumps({"garmin_email": garmin_email}, indent=2),
            encoding="utf-8",
        )
        print(f"Garmin-Anmeldung erfolgreich (Garmin-Konto: {garmin_email}).")

    try:
        response = api.upload_activity(str(path))
    except (
        GarminConnectConnectionError,
        GarminConnectAuthenticationError,
        GarminConnectTooManyRequestsError,
    ):
        raise RuntimeError(
            "Garmin-Upload fehlgeschlagen oder Ergebnis unklar. Nicht als "
            "synchronisiert gespeichert. Aktivitaet in Garmin pruefen, bevor "
            "du erneut startest."
        ) from None

    status, activity_id = import_result(response)
    state["uploads"][digest] = {
        "file": path.name,
        "status": status,
        "garmin_activity_id": activity_id,
    }
    save_state(state_path, state)

    if status == "duplicate":
        print("Garmin bestaetigt: Aktivitaet bereits vorhanden (Code 202).")
    else:
        print("Garmin-Upload erfolgreich. Aktivitaets-ID:", activity_id or "nicht angegeben")
