import "./landing.css";

const acceptanceCheckbox = document.querySelector("#accept-test-notice");
const signInButton = document.querySelector("#sign-in-button");
const acceptanceHelp = document.querySelector("#acceptance-help");

const TERMS_VERSION = "2026-11-03-test-1";

function updateAcceptanceState() {
    const accepted = acceptanceCheckbox.checked;
    signInButton.disabled = !accepted;
    acceptanceHelp.textContent = accepted
        ? `Terms and Test Notice ${TERMS_VERSION} accepted for this sign-in.`
        : "Accept the test notice to enable sign-in.";
}

acceptanceCheckbox.addEventListener("change", updateAcceptanceState);
updateAcceptanceState();
