import os
import re
from datetime import datetime, timezone
from functools import lru_cache

from azure.core.exceptions import ResourceNotFoundError
from azure.data.tables import TableClient, UpdateMode
from azure.identity import DefaultAzureCredential

from datetime import datetime, timedelta, timezone

from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError,
)


_USER_ID_PATTERN = re.compile(r"^usr-[a-z0-9-]{1,50}$")
_SHA256_PATTERN = re.compile(r"^[a-f0-9]{64}$")

_ALLOWED_STATUSES = {
    "pending",
    "uploaded",
    "duplicate",
    "failed",
}
_LOCK_TIMEOUT = timedelta(minutes=15)


def _validate_user_id(user_id: str) -> str:
    normalized = user_id.strip().lower()

    if not _USER_ID_PATTERN.fullmatch(normalized):
        raise ValueError("Ungültige interne Benutzer-ID.")

    return normalized


def _validate_file_hash(file_hash: str) -> str:
    normalized = file_hash.strip().lower()

    if not _SHA256_PATTERN.fullmatch(normalized):
        raise ValueError("Ungültiger SHA-256-Hash.")

    return normalized


def _validate_status(status: str) -> str:
    normalized = status.strip().lower()

    if normalized not in _ALLOWED_STATUSES:
        raise ValueError("Ungültiger Uploadstatus.")

    return normalized


@lru_cache(maxsize=1)
def _get_table_client() -> TableClient:
    endpoint = os.getenv("TABLE_STORAGE_ENDPOINT", "").strip()
    table_name = os.getenv("UPLOAD_HISTORY_TABLE", "").strip()

    if not endpoint:
        raise RuntimeError("TABLE_STORAGE_ENDPOINT fehlt.")

    if not table_name:
        raise RuntimeError("UPLOAD_HISTORY_TABLE fehlt.")

    return TableClient(
        endpoint=endpoint,
        table_name=table_name,
        credential=DefaultAzureCredential(),
    )


def get_upload(user_id: str, file_hash: str) -> dict | None:
    validated_user_id = _validate_user_id(user_id)
    validated_hash = _validate_file_hash(file_hash)

    try:
        entity = _get_table_client().get_entity(
            partition_key=validated_user_id,
            row_key=validated_hash,
        )
        return dict(entity)

    except ResourceNotFoundError:
        return None


def upload_exists(user_id: str, file_hash: str) -> bool:
    entity = get_upload(user_id, file_hash)

    if entity is None:
        return False

    return entity.get("Status") in {
        "uploaded",
        "duplicate",
    }


def save_upload(
    user_id: str,
    file_hash: str,
    status: str,
    file_size: int,
    garmin_activity_id: str | None = None,
) -> None:
    validated_user_id = _validate_user_id(user_id)
    validated_hash = _validate_file_hash(file_hash)
    validated_status = _validate_status(status)

    if not isinstance(file_size, int) or file_size < 0:
        raise ValueError("Ungültige Dateigröße.")

    entity = {
        "PartitionKey": validated_user_id,
        "RowKey": validated_hash,
        "Status": validated_status,
        "ProcessedAt": datetime.now(timezone.utc),
        "Source": "mywhoosh",
        "FileSize": file_size,
        "SchemaVersion": 1,
    }

    if garmin_activity_id:
        entity["GarminActivityId"] = str(garmin_activity_id)

    _get_table_client().upsert_entity(
        entity=entity,
        mode=UpdateMode.MERGE,
)


def delete_upload(user_id: str, file_hash: str) -> None:
    validated_user_id = _validate_user_id(user_id)
    validated_hash = _validate_file_hash(file_hash)

    try:
        _get_table_client().delete_entity(
            partition_key=validated_user_id,
            row_key=validated_hash,
        )
    except ResourceNotFoundError:
        pass
def acquire_upload_lock(
    user_id: str,
    file_hash: str,
    file_size: int,
) -> str:
    validated_user_id = _validate_user_id(user_id)
    validated_hash = _validate_file_hash(file_hash)

    if not isinstance(file_size, int) or file_size < 0:
        raise ValueError("Ungültige Dateigröße.")

    now = datetime.now(timezone.utc)

    entity = {
        "PartitionKey": validated_user_id,
        "RowKey": validated_hash,
        "Status": "pending",
        "LockAcquiredAt": now,
        "ProcessedAt": now,
        "Source": "mywhoosh",
        "FileSize": file_size,
        "SchemaVersion": 1,
    }

    try:
        _get_table_client().create_entity(entity=entity)
        return "acquired"

    except ResourceExistsError:
        existing = get_upload(
            validated_user_id,
            validated_hash,
        )

        if existing is None:
            # Seltene Race Condition zwischen Konflikt und erneutem Lesen.
            return "busy"

        status = str(
            existing.get("Status", "")
        ).strip().lower()

        if status in {"uploaded", "duplicate"}:
            return "completed"

        if status == "pending":
            lock_time = existing.get("LockAcquiredAt")

            if isinstance(lock_time, datetime):
                if lock_time.tzinfo is None:
                    lock_time = lock_time.replace(
                        tzinfo=timezone.utc
                    )

                if now - lock_time >= _LOCK_TIMEOUT:
                    return "stale"

            return "busy"

        return "busy"


def release_upload_lock(
    user_id: str,
    file_hash: str,
) -> None:
    entity = get_upload(user_id, file_hash)

    if entity is None:
        return

    status = str(
        entity.get("Status", "")
    ).strip().lower()

    if status == "pending":
        delete_upload(user_id, file_hash)
def delete_all_uploads_for_user(
    user_id: str,
) -> int:
    table_client = _get_table_client()

    entities = table_client.query_entities(
        query_filter="PartitionKey eq @user_id",
        parameters={
            "user_id": user_id,
        },
        select=[
            "PartitionKey",
            "RowKey",
        ],
    )

    deleted_count = 0

    for entity in entities:
        table_client.delete_entity(
            partition_key=entity["PartitionKey"],
            row_key=entity["RowKey"],
        )

        deleted_count += 1

    return deleted_count